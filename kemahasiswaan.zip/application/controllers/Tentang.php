<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tentang extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
        $this->halaman = 'tentang';
	}
	
	public function index() {
      $data = [
         'halaman'    => $this->halaman,
         'main'       => 'tentang',
         'tentang'	 => $this->db->get('tentang')->row()
      ];
      $this->load->view('layouts/template', $data);
   }

}