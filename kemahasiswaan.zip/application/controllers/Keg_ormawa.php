<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keg_ormawa extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
        $this->halaman = 'keg_ormawa';
	}
	
	public function index() {
      $data = [
         'halaman'    => $this->halaman,
         'main'       => 'keg_ormawa',
         'keg_ormawa'	 => $this->db->get('keg_ormawa')->result()
      ];
      $this->load->view('layouts/template', $data);
   }

   public function detail($id_ko) {
      $data = [
         'halaman'    => $this->halaman,
         'main'       => 'detail_keg_ormawa',
         'keg_ormawa'    => $this->db->where('id_ko', $id_ko)->get('keg_ormawa')->row()
      ];
      $this->load->view('layouts/template', $data);
   }
}