<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keg_mhs extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
        $this->halaman = 'keg_mhs';
	}
	
	public function index() {
      $data = [
         'halaman'    => $this->halaman,
         'main'       => 'keg_mhs',
         'keg_mhs'	 => $this->db->get('keg_mhs')->result()
      ];
      $this->load->view('layouts/template', $data);
   }

   public function detail($id_keg_mhs) {
      $data = [
         'halaman'    => $this->halaman,
         'main'       => 'detail_keg_mhs',
         'keg_mhs'    => $this->db->where('id_keg_mhs', $id_keg_mhs)->get('keg_mhs')->row()
      ];
      $this->load->view('layouts/template', $data);
   }
}