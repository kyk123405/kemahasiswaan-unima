<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Pkm extends Prodi_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Pkm_model', 'pkm');
        $this->id_prodi = $this->session->userdata('id_prodi');

        $this->halaman = 'pkm';
    }

    public function index() {
        $data = [
            'halaman'     => $this->halaman,
            'main'        => 'prodi/pkm/list',
            'id_prodi' => $this->id_prodi
        ];

        $this->load->view('prodi/layouts/template', $data);
    }

    public function dokumentasi($id_pkm) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'prodi/pkm/dokumentasi',
            'id_pkm' => $id_pkm
        ];

        $this->load->view('prodi/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->pkm->get_total_prodi($this->id_prodi);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->pkm->get_datatables_search_prodi($search, $start, $length, $this->id_prodi);
        } else {
            $list = $this->pkm->get_datatables_prodi($start, $length, $this->id_prodi);
        }

        if($search !== "") {
            $total_search = $this->pkm->get_total_search_prodi($search, $this->id_prodi);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            $prodi = $this->db->where('id_prodi', $keg->id_prodi)->get('prodi')->row();

            $row = array();
            $row[] = $no;
            $row[] = $prodi->nama_prodi;
            $row[] = $keg->tahun;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_pkm;
            $row[] = word_limiter($keg->deskripsi_pkm, 30);
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$keg->id_pkm.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$keg->id_pkm.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="detail('.$keg->id_pkm.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('prodi/pkm/dokumentasi/'. $keg->id_pkm) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-plus"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_pkm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->pkm->get_total_dokumentasi($id_pkm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->pkm->get_datatables_search_dokumentasi($search, $start, $length, $id_pkm);
        } else {
            $list = $this->pkm->get_datatables_dokumentasi($start, $length, $id_pkm);
        }

        if($search !== "") {
            $total_search = $this->pkm->get_total_search_dokumentasi($search, $id_pkm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/pkm/'.$dokumentasi->file).'" alt="" width="250px">';
            $row[] = '<a href="javascript:void(0)" onclick="edit_dokumentasi('.$dokumentasi->id_dp.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus_dokumentasi('.$dokumentasi->id_dp.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_pkm) {
        $data = $this->pkm->where('id_pkm', $id_pkm)->get();
        echo json_encode($data);
    }

    public function ajax_edit_dokumentasi($id_dp) {
        $data = $this->db->where('id_dp', $id_dp)->get('dokumentasi_pkm')->row();
        echo json_encode($data);
    }

    public function ajax_add() {
        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [     
            'nama_pkm'      => $this->input->post('nama_pkm'),
            'deskripsi_pkm' => $this->input->post('deskripsi_pkm'),
            'tingkat'       => $this->input->post('tingkat'),
            'tahun'         => $this->input->post('tahun'),
            'id_fakultas'   => $prodi->id_fakultas,
            'id_prodi'      => $this->id_prodi,
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $insert = $this->pkm->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_add_dokumentasi() {

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_pkm' => $this->input->post('id_pkm'),
            'file'      => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->db->insert('dokumentasi_pkm', $data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_pkm = $this->input->post('id_pkm');
        $pkm = $this->db->where('id_pkm', $id_pkm)->get('pkm')->row();
        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [           
            'nama_pkm'      => $this->input->post('nama_pkm'),
            'deskripsi_pkm' => $this->input->post('deskripsi_pkm'),
            'tingkat'       => $this->input->post('tingkat'),
            'tahun'         => $this->input->post('tahun'),
            'id_fakultas'   => $prodi->id_fakultas,
            'id_prodi'      => $this->id_prodi,
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_pkm', $id_pkm)->update('pkm',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update_dokumentasi() {
        $id_dp      = $this->input->post('id_dp');
        $dokumentasi_pkm = $this->db->where('id_dp', $id_dp)->get('dokumentasi_pkm')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $dokumentasi_pkm->file;
        }

        $data = [
            'id_pkm' => $this->input->post('id_pkm'),
            'file'       => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_dp', $id_dp)->update('dokumentasi_pkm',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_pkm) {
        $delete = $this->pkm->where('id_pkm', $id_pkm)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete_dokumentasi($id_dp) {
        $delete = $this->db->where('id_dp', $id_dp)->delete('dokumentasi_pkm');

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function detail($id_pkm) {
        $pkm = $this->db->where('id_pkm', $id_pkm)->get('pkm')->row();

        $data = [
            'id_pkm'        => $pkm->id_pkm,
            'nama_pkm'      => $pkm->nama_pkm,
            'deskripsi_pkm' => $pkm->deskripsi_pkm,
            'tahun'        => $pkm->tahun,
            'tingkat'      => $pkm->tingkat,
            'tgl_input'    => format_tanggal($pkm->tgl_input),
        ];

        echo json_encode($data);
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/pkm/';
        $config['allowed_types'] ='jpg|png|jpeg|JPG|JPEG|PNG';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}