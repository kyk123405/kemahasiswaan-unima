<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_prodi extends MY_Controller {	

    public function __construct() {
        parent::__construct();
        $this->load->model('Login_prodi_model', 'login');
    }

	public function index() {
        if (!$_POST) {
            $input = (object) $this->login->getDefaultValues();
        } else {
            $input = (object) $this->input->post(null, true);
        }

        if (!$this->login->validate()) {
            $this->load->view('auths/login_prodi', compact('input'));
            return;
        }

        if ($this->login->login($input)) {            
            redirect('prodi/dashboard');
        } else {
            $this->session->set_flashdata('message', 'Username atau password salah, Coba lagi!');
        }

        redirect('prodi/login_prodi');
	}

	public function logout() {		
        $this->login->logout();
        redirect('prodi/login_prodi');
	}
}