<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Prodi_Controller {

	public function __construct() {
		parent::__construct();

        $this->halaman = 'dashboard';
	}
	
	public function index() {
        $data = [
			'halaman'     => $this->halaman,
			'main'        => 'prodi/dashboard',
			'id_prodi' => $this->session->userdata('id_prodi')
        ];

		$this->load->view('prodi/layouts/template', $data);
	}
}