<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Prestasi_talenta extends Prodi_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Prestasi_talenta_model', 'prestasi_talenta');
        $this->id_prodi = $this->session->userdata('id_prodi');

        $this->halaman = 'prestasi_talenta';
    }

    public function index() {
        $data = [
            'halaman'     => $this->halaman,
            'main'        => 'prodi/prestasi_talenta/list',
            'id_prodi' => $this->id_prodi
        ];

        $this->load->view('prodi/layouts/template', $data);
    }

    public function dokumentasi($id_pt) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'prodi/prestasi_talenta/dokumentasi',
            'id_pt' => $id_pt
        ];

        $this->load->view('prodi/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_talenta->get_total_prodi($this->id_prodi);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_talenta->get_datatables_search_prodi($search, $start, $length, $this->id_prodi);
        } else {
            $list = $this->prestasi_talenta->get_datatables_prodi($start, $length, $this->id_prodi);
        }

        if($search !== "") {
            $total_search = $this->prestasi_talenta->get_total_search_prodi($search, $this->id_prodi);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            $prodi = $this->db->where('id_prodi', $keg->id_prodi)->get('prodi')->row();

            $row = array();
            $row[] = $no;
            $row[] = $prodi->nama_prodi;
            $row[] = $keg->tahun;
            $row[] = $keg->juara;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_pt;
            $row[] = word_limiter($keg->deskripsi_pt, 30);
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$keg->id_pt.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$keg->id_pt.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="detail('.$keg->id_pt.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('prodi/prestasi_talenta/dokumentasi/'. $keg->id_pt) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-plus"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_pt) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_talenta->get_total_dokumentasi($id_pt);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_talenta->get_datatables_search_dokumentasi($search, $start, $length, $id_pt);
        } else {
            $list = $this->prestasi_talenta->get_datatables_dokumentasi($start, $length, $id_pt);
        }

        if($search !== "") {
            $total_search = $this->prestasi_talenta->get_total_search_dokumentasi($search, $id_pt);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/prestasi_talenta/'.$dokumentasi->file).'" alt="" width="250px">';
            $row[] = '<a href="javascript:void(0)" onclick="edit_dokumentasi('.$dokumentasi->id_dokumentasi_pt.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus_dokumentasi('.$dokumentasi->id_dokumentasi_pt.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_pt) {
        $data = $this->prestasi_talenta->where('id_pt', $id_pt)->get();
        echo json_encode($data);
    }

    public function ajax_edit_dokumentasi($id_dokumentasi_pt) {
        $data = $this->db->where('id_dokumentasi_pt', $id_dokumentasi_pt)->get('dokumentasi_pt')->row();
        echo json_encode($data);
    }

    public function ajax_add() {
        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [     
            'nama_pt'      => $this->input->post('nama_pt'),
            'deskripsi_pt' => $this->input->post('deskripsi_pt'),
            'id_fakultas' => $prodi->id_fakultas,
            'id_prodi'    => $this->id_prodi,
            'tingkat'      => $this->input->post('tingkat'),
            'tahun'        => $this->input->post('tahun'),
            'juara'        => $this->input->post('juara'),
            'tgl_input'    => date('Y-m-d H:i:s')
        ];

        $insert = $this->prestasi_talenta->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_add_dokumentasi() {

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_pt' => $this->input->post('id_pt'),
            'file'      => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->db->insert('dokumentasi_pt', $data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_pt = $this->input->post('id_pt');
        $prestasi_talenta = $this->db->where('id_pt', $id_pt)->get('prestasi_talenta')->row();
        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [           
            'nama_pt'      => $this->input->post('nama_pt'),
            'deskripsi_pt' => $this->input->post('deskripsi_pt'),
            'id_fakultas' => $prodi->id_fakultas,
            'id_prodi'    => $this->id_prodi,
            'tingkat'      => $this->input->post('tingkat'),
            'tahun'        => $this->input->post('tahun'),
            'juara'        => $this->input->post('juara'),
            'tgl_input'    => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_pt', $id_pt)->update('prestasi_talenta',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update_dokumentasi() {
        $id_dokumentasi_pt      = $this->input->post('id_dokumentasi_pt');
        $dokumentasi_pt = $this->db->where('id_dokumentasi_pt', $id_dokumentasi_pt)->get('dokumentasi_pt')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $dokumentasi_pt->file;
        }

        $data = [
            'id_pt' => $this->input->post('id_pt'),
            'file'       => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_dokumentasi_pt', $id_dokumentasi_pt)->update('dokumentasi_pt',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_pt) {
        $delete = $this->prestasi_talenta->where('id_pt', $id_pt)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete_dokumentasi($id_dokumentasi_pt) {
        $delete = $this->db->where('id_dokumentasi_pt', $id_dokumentasi_pt)->delete('dokumentasi_pt');

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function detail($id_pt) {
        $prestasi_talenta = $this->db->where('id_pt', $id_pt)->get('prestasi_talenta')->row();
        $prodi     = $this->db->where('id_prodi', $prestasi_talenta->id_prodi)->get('prodi')->row();

        $data = [
            'id_pt'        => $prestasi_talenta->id_pt,
            'nama_pt'      => $prestasi_talenta->nama_pt,
            'deskripsi_pt' => $prestasi_talenta->deskripsi_pt,
            'tahun'        => $prestasi_talenta->tahun,
            'tingkat'      => $prestasi_talenta->tingkat,
            'juara'        => $prestasi_talenta->juara,
            'id_prodi'     => $prodi->nama_prodi,
            'tgl_input'    => format_tanggal($prestasi_talenta->tgl_input),
        ];

        echo json_encode($data);
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/prestasi_talenta/';
        $config['allowed_types'] ='jpg|png|jpeg|JPG|JPEG|PNG';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}