<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Ormawa extends Prodi_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Ormawa_model', 'ormawa');
        $this->id_prodi = $this->session->userdata('id_prodi');

        $this->halaman = 'ormawa';
    }

    public function index() {
        $data = [
            'halaman'     => $this->halaman,
            'id_prodi' => $this->id_prodi,
            'main'        => 'prodi/ormawa/list',
        ];

        $this->load->view('prodi/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ormawa->get_total_prodi($this->id_prodi);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ormawa->get_datatables_search_prodi($search, $start, $length, $this->id_prodi);
        } else {
            $list = $this->ormawa->get_datatables_prodi($start, $length, $this->id_prodi);
        }

        if($search !== "") {
            $total_search = $this->ormawa->get_total_search_prodi($search, $this->id_prodi);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $ormawa) {
            $prodi = $this->db->where('id_prodi', $ormawa->id_prodi)->get('prodi')->row();
            
            $row = array();
            $row[] = $no;
            $row[] = $prodi->nama_prodi;
            $row[] = $ormawa->tahun;
            $row[] = $ormawa->jlh_ormawa;
            $row[] = '<a href="'.base_url('uploads/ormawa/'. $ormawa->file) .'" target="_blank" class="btn btn-outline-success btn-m">
                        <i class="fas fa-fw fa-eye"></i> Lihat File
                      </a>
                      <a href="javascript:void(0)" onclick="edit('.$ormawa->id_ormawa.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$ormawa->id_ormawa.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_ormawa) {
        $data = $this->ormawa->where('id_ormawa', $id_ormawa)->get();
        echo json_encode($data);
    }

    public function ajax_add() {
        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [     
            'tahun'       => $this->input->post('tahun'),
            'jlh_ormawa'  => $this->input->post('jlh_ormawa'),
            'id_fakultas' => $prodi->id_fakultas,
            'id_prodi'    => $this->id_prodi,
            'file'        => $file,
            'tgl_input'   => date('Y-m-d H:i:s')
        ];

        $insert = $this->ormawa->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_ormawa = $this->input->post('id_ormawa');
        $ormawa = $this->db->where('id_ormawa', $id_ormawa)->get('ormawa')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $ormawa->file;
        }

        $prodi = $this->db->where('id_prodi', $this->id_prodi)->get('prodi')->row();

        $data = [    
            'tahun'       => $this->input->post('tahun'),
            'jlh_ormawa'  => $this->input->post('jlh_ormawa'),
            'id_fakultas' => $prodi->id_fakultas,
            'id_prodi'    => $this->id_prodi,
            'file'        => $file,
            'tgl_input'   => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_ormawa', $id_ormawa)->update('ormawa',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_ormawa) {
        $delete = $this->ormawa->where('id_ormawa', $id_ormawa)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/ormawa/';
        $config['allowed_types'] ='xlsx|xls';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}