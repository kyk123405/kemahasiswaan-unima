<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Mbkm extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Mbkm_model', 'mbkm');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'mbkm';
    }

    public function data($id_jm) {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/mbkm/list',
            'id_jm'   => $id_jm
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list($id_jm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->mbkm->get_total($id_jm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->mbkm->get_datatables_search($search, $start, $length, $id_jm);
        } else {
            $list = $this->mbkm->get_datatables($start, $length, $id_jm);
        }

        if($search !== "") {
            $total_search = $this->mbkm->get_total_search($search, $id_jm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $mbkm) {
            $fakultas = $this->db->where('id_fakultas', $mbkm->id_fakultas)->get('fakultas')->row();
            $prodi = $this->db->where('id_prodi', $mbkm->id_prodi)->get('prodi')->row();
            $jenis    = $this->db->where('id_jm', $id_jm)->get('jenis_mbkm')->row();

            $row = array();
            $row[] = $no;
            $row[] = $fakultas->nama_fakultas;
            $row[] = $prodi->nama_prodi;
            $row[] = $jenis->nama_jm;
            $row[] = $mbkm->tahun;
            $row[] = $mbkm->jumlah;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$mbkm->id_mbkm.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$mbkm->id_mbkm.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_mbkm) {
        $data = $this->mbkm->where('id_mbkm', $id_mbkm)->get();
        echo json_encode($data);
    }

    public function ajax_add() {
        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_fakultas' => $this->input->post('id_fakultas'),
            'id_prodi'    => $this->input->post('id_prodi'),
            'id_jm'       => $this->input->post('id_jm'),
            'tahun'       => $this->input->post('tahun'),
            'jumlah'      => $this->input->post('jumlah'),
            'tgl_input'   => date('Y-m-d H:i:s'),
            'file'        => $file,
        ];

        $insert = $this->mbkm->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_mbkm = $this->input->post('id_mbkm');
        $mbkm    = $this->db->where('id_mbkm', $id_mbkm)->get('mbkm')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $mbkm->file;
        }

        $data = [
            'id_ko'     => $this->input->post('id_ko'),
            'file'      => $file,
            'tgl_input' => date('Y-m-d H:i:s')
        ];

        $data = [    
            'id_fakultas' => $this->input->post('id_fakultas'),
            'id_prodi'    => $this->input->post('id_prodi'),
            'id_jm'       => $this->input->post('id_jm'),
            'tahun'       => $this->input->post('tahun'),
            'jumlah'      => $this->input->post('jumlah'),
            'tgl_input'   => date('Y-m-d H:i:s'),
            'file'        => $file,
        ];

        $update = $this->db->where('id_mbkm', $id_mbkm)->update('mbkm',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_mbkm) {
        $delete = $this->mbkm->where('id_mbkm', $id_mbkm)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/mbkm/';
        $config['allowed_types'] ='xlsx|xls';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}