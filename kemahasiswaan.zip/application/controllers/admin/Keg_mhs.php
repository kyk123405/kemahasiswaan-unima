<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Keg_mhs extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Keg_mhs_model', 'keg_mhs');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'keg_mhs';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/keg_mhs/list',
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function dokumentasi($id_keg_mhs) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'admin/keg_mhs/dokumentasi',
            'id_keg_mhs' => $id_keg_mhs
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->keg_mhs->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->keg_mhs->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->keg_mhs->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->keg_mhs->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/keg_mhs/'.$keg->cover).'" alt="" width="250px">';
            $row[] = format_tanggal($keg->tgl_keg);
            $row[] = $keg->nama_keg;
            $row[] = word_limiter($keg->isi_keg, 30);
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$keg->id_keg_mhs.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$keg->id_keg_mhs.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="detail('.$keg->id_keg_mhs.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('admin/keg_mhs/dokumentasi/'. $keg->id_keg_mhs) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-plus"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_keg_mhs) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->keg_mhs->get_total_dokumentasi($id_keg_mhs);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->keg_mhs->get_datatables_search_dokumentasi($search, $start, $length, $id_keg_mhs);
        } else {
            $list = $this->keg_mhs->get_datatables_dokumentasi($start, $length, $id_keg_mhs);
        }

        if($search !== "") {
            $total_search = $this->keg_mhs->get_total_search_dokumentasi($search, $id_keg_mhs);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/keg_mhs/'.$dokumentasi->file).'" alt="" width="250px">';
            $row[] = $dokumentasi->deskripsi;
            $row[] = '<a href="javascript:void(0)" onclick="edit_dokumentasi('.$dokumentasi->id_dok_keg_mhs.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus_dokumentasi('.$dokumentasi->id_dok_keg_mhs.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_keg_mhs) {
        $data = $this->keg_mhs->where('id_keg_mhs', $id_keg_mhs)->get();
        echo json_encode($data);
    }

    public function ajax_edit_dokumentasi($id_dok_keg_mhs) {
        $data = $this->db->where('id_dok_keg_mhs', $id_dok_keg_mhs)->get('dokumentasi_keg_mhs')->row();
        echo json_encode($data);
    }

    public function ajax_add() {

        if ( ! empty($_FILES['cover']['name'])) {
            $upload = $this->file_upload('cover');
            $cover = $upload;
        } else {
            $cover = null;
        } 

        $data = [     
            'nama_keg'  => $this->input->post('nama_keg'),
            'tgl_keg'   => $this->input->post('tgl_keg'),
            'isi_keg'   => $this->input->post('isi_keg'),
            'cover'     => $cover,
            'tgl_input' => date('Y-m-d H:i:s')
        ];

        $insert = $this->keg_mhs->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_add_dokumentasi() {

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_keg_mhs' => $this->input->post('id_keg_mhs'),
            'deskripsi' => $this->input->post('deskripsi'),
            'file'      => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->db->insert('dokumentasi_keg_mhs', $data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_keg_mhs = $this->input->post('id_keg_mhs');
        $keg_mhs = $this->db->where('id_keg_mhs', $id_keg_mhs)->get('keg_mhs')->row();

        if ( ! empty($_FILES['cover']['name'])) {
            $upload = $this->file_upload('cover');
            $cover = $upload;
        } else {
            $cover = $keg_mhs->cover;
        }

        $data = [           
            'nama_keg'  => $this->input->post('nama_keg'),
            'tgl_keg'   => $this->input->post('tgl_keg'),
            'isi_keg'   => $this->input->post('isi_keg'),
            'cover'     => $cover,
            'tgl_input' => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_keg_mhs', $id_keg_mhs)->update('keg_mhs',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update_dokumentasi() {
        $id_dok_keg_mhs      = $this->input->post('id_dok_keg_mhs');
        $dokumentasi_keg_mhs = $this->db->where('id_dok_keg_mhs', $id_dok_keg_mhs)->get('dokumentasi_keg_mhs')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $dokumentasi_keg_mhs->file;
        }

        $data = [
            'id_keg_mhs' => $this->input->post('id_keg_mhs'),
            'file'       => $file,
            'deskripsi' => $this->input->post('deskripsi'),
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_dok_keg_mhs', $id_dok_keg_mhs)->update('dokumentasi_keg_mhs',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_keg_mhs) {
        $delete = $this->keg_mhs->where('id_keg_mhs', $id_keg_mhs)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete_dokumentasi($id_dok_keg_mhs) {
        $delete = $this->db->where('id_dok_keg_mhs', $id_dok_keg_mhs)->delete('dokumentasi_keg_mhs');

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function detail($id_keg_mhs) {
        $keg_mhs = $this->db->where('id_keg_mhs', $id_keg_mhs)->get('keg_mhs')->row();

        $data = [
            'id_keg_mhs' => $keg_mhs->id_keg_mhs,
            'tgl_keg'    => $keg_mhs->tgl_keg,
            'nama_keg'   => $keg_mhs->nama_keg,
            'isi_keg'    => $keg_mhs->isi_keg,
        ];

        echo json_encode($data);
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/keg_mhs/';
        $config['allowed_types'] ='jpg|png|jpeg|JPG|JPEG|PNG';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}