<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin_Controller {

	public function __construct() {
		parent::__construct();

        $this->halaman = 'dashboard';
	}
	
	public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/dashboard',
        ];

		$this->load->view('admin/layouts/template', $data);
	}
}