<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Jenis_mbkm extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Jenis_mbkm_model', 'jenis_mbkm');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'jenis_mbkm';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/jenis_mbkm/list',
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->jenis_mbkm->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->jenis_mbkm->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->jenis_mbkm->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->jenis_mbkm->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $jenis_mbkm) {
            
            $row = array();
            $row[] = $no;
            $row[] = $jenis_mbkm->nama_jm;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$jenis_mbkm->id_jm.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$jenis_mbkm->id_jm.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_jm) {
        $data = $this->jenis_mbkm->where('id_jm', $id_jm)->get();
        echo json_encode($data);
    }

    public function ajax_add() {

        $data = [     
            'nama_jm' => $this->input->post('nama_jm'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $insert = $this->jenis_mbkm->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_jm = $this->input->post('id_jm');
        $jenis_mbkm = $this->db->where('id_jm', $id_jm)->get('jenis_mbkm')->row();

        $data = [    
            'nama_jm' => $this->input->post('nama_jm'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_jm', $id_jm)->update('jenis_mbkm',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_jm) {
        $delete = $this->jenis_mbkm->where('id_jm', $id_jm)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }
}