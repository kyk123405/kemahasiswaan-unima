<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Fakultas extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Fakultas_model', 'fakultas');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'fakultas';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/fakultas/list',
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->fakultas->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->fakultas->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->fakultas->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->fakultas->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $fakultas) {
            
            $row = array();
            $row[] = $no;
            $row[] = $fakultas->singkatan;
            $row[] = $fakultas->nama_fakultas;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$fakultas->id_fakultas.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$fakultas->id_fakultas.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_fakultas) {
        $data = $this->fakultas->where('id_fakultas', $id_fakultas)->get();
        echo json_encode($data);
    }

    public function ajax_add() {

        $data = [     
            'singkatan'     => $this->input->post('singkatan'),
            'nama_fakultas' => $this->input->post('nama_fakultas'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $insert = $this->fakultas->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_fakultas = $this->input->post('id_fakultas');
        $fakultas = $this->db->where('id_fakultas', $id_fakultas)->get('fakultas')->row();

        $data = [           
            'singkatan'     => $this->input->post('singkatan'),
            'nama_fakultas' => $this->input->post('nama_fakultas'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_fakultas', $id_fakultas)->update('fakultas',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_fakultas) {
        $delete = $this->fakultas->where('id_fakultas', $id_fakultas)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }
}