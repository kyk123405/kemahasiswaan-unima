<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Ormawa extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Ormawa_model', 'ormawa');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'ormawa';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/ormawa/list',
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ormawa->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ormawa->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->ormawa->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->ormawa->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $ormawa) {
            
            $row = array();
            $row[] = $no;
            $row[] = $ormawa->tahun;
            $row[] = $ormawa->jlh_ormawa;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$ormawa->id_ormawa.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$ormawa->id_ormawa.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_ormawa) {
        $data = $this->ormawa->where('id_ormawa', $id_ormawa)->get();
        echo json_encode($data);
    }

    public function ajax_add() {

        $data = [     
            'tahun'      => $this->input->post('tahun'),
            'jlh_ormawa' => $this->input->post('jlh_ormawa'),
            'id_fakultas'   => $this->input->post('id_fakultas'),
            'id_prodi'      => $this->input->post('id_prodi'),
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->ormawa->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_ormawa = $this->input->post('id_ormawa');
        $ormawa = $this->db->where('id_ormawa', $id_ormawa)->get('ormawa')->row();

        $data = [    
            'tahun'      => $this->input->post('tahun'),
            'jlh_ormawa' => $this->input->post('jlh_ormawa'),
            'id_fakultas'   => $this->input->post('id_fakultas'),
            'id_prodi'      => $this->input->post('id_prodi'),
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_ormawa', $id_ormawa)->update('ormawa',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_ormawa) {
        $delete = $this->ormawa->where('id_ormawa', $id_ormawa)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }
}