<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Prodi extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Prodi_model', 'prodi');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'prodi';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/prodi/list',
        ];

        $this->load->view('layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prodi->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prodi->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->prodi->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->prodi->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $prodi) {
            $fakultas = $this->db->where('id_fakultas', $prodi->id_fakultas)->get('fakultas')->row();
            
            $row = array();
            $row[] = $no;
            $row[] = $fakultas->nama_fakultas;
            $row[] = $prodi->singkatan;
            $row[] = $prodi->nama_prodi;
            $row[] = $prodi->username;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$prodi->id_prodi.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$prodi->id_prodi.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_prodi) {
        $data = $this->prodi->where('id_prodi', $id_prodi)->get();
        echo json_encode($data);
    }

    public function ajax_add() {

        $data = [     
            'id_fakultas' => $this->input->post('id_fakultas'),
            'singkatan'   => $this->input->post('singkatan'),
            'nama_prodi'  => $this->input->post('nama_prodi'),
            'username'    => $this->input->post('username'),
            'password'    => md5($this->input->post('password')),
        ];

        $insert = $this->prodi->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_prodi = $this->input->post('id_prodi');
        $prodi = $this->db->where('id_prodi', $id_prodi)->get('prodi')->row();

        if (empty($this->input->post('password'))) {
            $password = $prodi->password;
        } else {
            $password = md5($this->input->post('password'));
        }

        $data = [           
            'singkatan'   => $this->input->post('singkatan'),
            'id_fakultas' => $this->input->post('id_fakultas'),
            'nama_prodi'  => $this->input->post('nama_prodi'),
            'username'    => $this->input->post('username'),
            'password'    => $password,
        ];

        $update = $this->db->where('id_prodi', $id_prodi)->update('prodi',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_prodi) {
        $delete = $this->prodi->where('id_prodi', $id_prodi)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }
}