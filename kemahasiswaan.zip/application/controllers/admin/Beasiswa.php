<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Beasiswa extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Beasiswa_model', 'beasiswa');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'beasiswa';
    }

    public function data($id_jb) {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/beasiswa/list',
            'id_jb'   => $id_jb
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list($id_jb) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->beasiswa->get_total($id_jb);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->beasiswa->get_datatables_search($search, $start, $length, $id_jb);
        } else {
            $list = $this->beasiswa->get_datatables($start, $length, $id_jb);
        }

        if($search !== "") {
            $total_search = $this->beasiswa->get_total_search($search, $id_jb);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $beasiswa) {
            $fakultas = $this->db->where('id_fakultas', $beasiswa->id_fakultas)->get('fakultas')->row();
            $prodi = $this->db->where('id_prodi', $beasiswa->prodi)->get('prodi')->row();
            $jenis    = $this->db->where('id_jb', $id_jb)->get('jenis_beasiswa')->row();

            $row = array();
            $row[] = $no;
            $row[] = $beasiswa->tahun;
            $row[] = $beasiswa->nim;
            $row[] = $beasiswa->nama;
            $row[] = $prodi->nama_prodi;
            $row[] = $fakultas->nama_fakultas;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$beasiswa->id_beasiswa.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$beasiswa->id_beasiswa.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_beasiswa) {
        $data = $this->beasiswa->where('id_beasiswa', $id_beasiswa)->get();
        echo json_encode($data);
    }

    public function ajax_add() {
        $prodi = $this->db->where('id_prodi', $this->input->post('prodi'))->get('prodi')->row();
        $fakultas = $this->db->where('id_fakultas', $prodi->id_fakultas)->get('fakultas')->row();

        $data = [     
            'prodi' => $this->input->post('prodi'),
            'id_jb'       => $this->input->post('id_jb'),
            'tahun'       => $this->input->post('tahun'),
            'nama'       => $this->input->post('nama'),
            'nim'       => $this->input->post('nim'),
            'id_fakultas'      => $fakultas->id_fakultas,
            'tgl_input'   => date('Y-m-d H:i:s')
        ];

        $insert = $this->beasiswa->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_beasiswa = $this->input->post('id_beasiswa');
        $beasiswa    = $this->db->where('id_beasiswa', $id_beasiswa)->get('beasiswa')->row();
        $prodi = $this->db->where('id_prodi', $this->input->post('prodi'))->get('prodi')->row();
        $fakultas = $this->db->where('id_fakultas', $prodi->id_fakultas)->get('fakultas')->row();

        $data = [    
            'prodi' => $this->input->post('prodi'),
            'id_jb'       => $this->input->post('id_jb'),
            'tahun'       => $this->input->post('tahun'),
            'nama'       => $this->input->post('nama'),
            'nim'       => $this->input->post('nim'),
            'id_fakultas'      => $fakultas->id_fakultas,
            'tgl_input'   => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_beasiswa', $id_beasiswa)->update('beasiswa',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_beasiswa) {
        $delete = $this->beasiswa->where('id_beasiswa', $id_beasiswa)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }
}