<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Ppk extends Admin_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Ppk_model', 'ppk');
        $this->nama_admin = $this->session->userdata('nama_admin');

        $this->halaman = 'ppk';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'admin/ppk/list',
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function dokumentasi($id_ppk) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'admin/ppk/dokumentasi',
            'id_ppk' => $id_ppk
        ];

        $this->load->view('admin/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ppk->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ppk->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->ppk->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->ppk->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            $fakultas = $this->db->where('id_fakultas', $keg->id_fakultas)->get('fakultas')->row();
            $prodi = $this->db->where('id_prodi', $keg->id_prodi)->get('prodi')->row();

            $row = array();
            $row[] = $no;
            $row[] = $fakultas->nama_fakultas;
            $row[] = $prodi->nama_prodi;
            $row[] = $keg->tahun;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_ppk;
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$keg->id_ppk.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$keg->id_ppk.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>
                      <a href="'.base_url('admin/ppk/dokumentasi/'. $keg->id_ppk) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-plus"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_ppk) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ppk->get_total_dokumentasi($id_ppk);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ppk->get_datatables_search_dokumentasi($search, $start, $length, $id_ppk);
        } else {
            $list = $this->ppk->get_datatables_dokumentasi($start, $length, $id_ppk);
        }

        if($search !== "") {
            $total_search = $this->ppk->get_total_search_dokumentasi($search, $id_ppk);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/ppk/'.$dokumentasi->file).'" alt="" width="250px">';
            $row[] = $dokumentasi->deskripsi;
            $row[] = '<a href="javascript:void(0)" onclick="edit_dokumentasi('.$dokumentasi->id_dp.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus_dokumentasi('.$dokumentasi->id_dp.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_ppk) {
        $data = $this->ppk->where('id_ppk', $id_ppk)->get();
        echo json_encode($data);
    }

    public function ajax_edit_dokumentasi($id_dp) {
        $data = $this->db->where('id_dp', $id_dp)->get('dokumentasi_ppk')->row();
        echo json_encode($data);
    }

    public function ajax_add() {
        $prodi = $this->db->where('id_prodi', $this->input->post('id_prodi'))->get('prodi')->row();
        $fakultas = $this->db->where('id_fakultas', $prodi->id_fakultas)->get('fakultas')->row();

        $data = [     
            'nama_ppk'      => $this->input->post('nama_ppk'),
            'deskripsi_ppk' => $this->input->post('deskripsi_ppk'),
            'tingkat'       => $this->input->post('tingkat'),
            'tahun'         => $this->input->post('tahun'),
            'id_fakultas'   => $fakultas->id_fakultas,
            'id_prodi'      => $this->input->post('id_prodi'),
            'jumlah'        => $this->input->post('jumlah'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $insert = $this->ppk->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_add_dokumentasi() {

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_ppk' => $this->input->post('id_ppk'),
            'file'      => $file,
            'deskripsi' => $this->input->post('deskripsi'),
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->db->insert('dokumentasi_ppk', $data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_ppk = $this->input->post('id_ppk');
        $ppk = $this->db->where('id_ppk', $id_ppk)->get('ppk')->row();

        $prodi = $this->db->where('id_prodi', $this->input->post('id_prodi'))->get('prodi')->row();
        $fakultas = $this->db->where('id_fakultas', $prodi->id_fakultas)->get('fakultas')->row();

        $data = [     
            'nama_ppk'      => $this->input->post('nama_ppk'),
            'deskripsi_ppk' => $this->input->post('deskripsi_ppk'),
            'tingkat'       => $this->input->post('tingkat'),
            'tahun'         => $this->input->post('tahun'),
            'id_fakultas'   => $fakultas->id_fakultas,
            'id_prodi'      => $this->input->post('id_prodi'),
            'jumlah'        => $this->input->post('jumlah'),
            'tgl_input'     => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_ppk', $id_ppk)->update('ppk',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update_dokumentasi() {
        $id_dp      = $this->input->post('id_dp');
        $dokumentasi_ppk = $this->db->where('id_dp', $id_dp)->get('dokumentasi_ppk')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $dokumentasi_ppk->file;
        }

        $data = [
            'id_ppk' => $this->input->post('id_ppk'),
            'file'       => $file,
            'deskripsi' => $this->input->post('deskripsi'),
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_dp', $id_dp)->update('dokumentasi_ppk',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_ppk) {
        $delete = $this->ppk->where('id_ppk', $id_ppk)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete_dokumentasi($id_dp) {
        $delete = $this->db->where('id_dp', $id_dp)->delete('dokumentasi_ppk');

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/ppk/';
        $config['allowed_types'] ='jpg|png|jpeg|JPG|JPEG|PNG';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}