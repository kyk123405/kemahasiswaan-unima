<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Pkm extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Pkm_model', 'pkm');

        $this->halaman = 'pkm';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/pkm/list',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function dokumentasi($id_pkm) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'public/pkm/dokumentasi',
            'id_pkm' => $id_pkm
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->pkm->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->pkm->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->pkm->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->pkm->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {

            $row = array();
            $row[] = $no;
            $row[] = $keg->tahun;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_pkm;
            $row[] = word_limiter($keg->deskripsi_pkm, 30);
            $row[] = '<a href="javascript:void(0)" onclick="detail('.$keg->id_pkm.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('public/pkm/dokumentasi/'. $keg->id_pkm) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_pkm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->pkm->get_total_dokumentasi($id_pkm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->pkm->get_datatables_search_dokumentasi($search, $start, $length, $id_pkm);
        } else {
            $list = $this->pkm->get_datatables_dokumentasi($start, $length, $id_pkm);
        }

        if($search !== "") {
            $total_search = $this->pkm->get_total_search_dokumentasi($search, $id_pkm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/pkm/'.$dokumentasi->file).'" alt="">';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function detail($id_pkm) {
        $pkm = $this->db->where('id_pkm', $id_pkm)->get('pkm')->row();

        $data = [
            'id_pkm'        => $pkm->id_pkm,
            'nama_pkm'      => $pkm->nama_pkm,
            'deskripsi_pkm' => $pkm->deskripsi_pkm,
            'tahun'        => $pkm->tahun,
            'tingkat'      => $pkm->tingkat,
            'tgl_input'    => format_tanggal($pkm->tgl_input),
        ];

        echo json_encode($data);
    }
}