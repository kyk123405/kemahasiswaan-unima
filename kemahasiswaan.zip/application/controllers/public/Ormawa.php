<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Ormawa extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Ormawa_model', 'ormawa');

        $this->halaman = 'ormawa';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/ormawa/list',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ormawa->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ormawa->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->ormawa->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->ormawa->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $ormawa) {
            
            $row = array();
            $row[] = $no;
            $row[] = $ormawa->tahun;
            $row[] = $ormawa->jlh_ormawa;

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }
}