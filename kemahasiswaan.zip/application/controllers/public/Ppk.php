<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Ppk extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Ppk_model', 'ppk');

        $this->halaman = 'ppk';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/ppk/list',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function dokumentasi($id_ppk) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'public/ppk/dokumentasi',
            'id_ppk' => $id_ppk
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ppk->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ppk->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->ppk->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->ppk->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {

            $row = array();
            $row[] = $no;
            $row[] = $keg->tahun;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_ppk;
            $row[] = word_limiter($keg->deskripsi_ppk, 30);
            $row[] = '<a href="'.base_url('public/ppk/dokumentasi/'. $keg->id_ppk) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_ppk) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->ppk->get_total_dokumentasi($id_ppk);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->ppk->get_datatables_search_dokumentasi($search, $start, $length, $id_ppk);
        } else {
            $list = $this->ppk->get_datatables_dokumentasi($start, $length, $id_ppk);
        }

        if($search !== "") {
            $total_search = $this->ppk->get_total_search_dokumentasi($search, $id_ppk);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/ppk/'.$dokumentasi->file).'" alt="">';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function detail($id_ppk) {
        $ppk = $this->db->where('id_ppk', $id_ppk)->get('ppk')->row();

        $data = [
            'id_ppk'        => $ppk->id_ppk,
            'nama_ppk'      => $ppk->nama_ppk,
            'deskripsi_ppk' => $ppk->deskripsi_ppk,
            'tahun'        => $ppk->tahun,
            'tingkat'      => $ppk->tingkat,
            'tgl_input'    => format_tanggal($ppk->tgl_input),
        ];

        echo json_encode($data);
    }
}