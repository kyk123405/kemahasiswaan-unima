<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Keg_ormawa extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Keg_ormawa_model', 'keg_ormawa');

        $this->halaman = 'keg_ormawa';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/keg_ormawa/list',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function dokumentasi($id_ko) {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/keg_ormawa/dokumentasi',
            'id_ko'   => $id_ko
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->keg_ormawa->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->keg_ormawa->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->keg_ormawa->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->keg_ormawa->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/keg_ormawa/'.$keg->cover).'" alt="" width="250px">';
            $row[] = format_tanggal($keg->tgl_keg);
            $row[] = $keg->nama_ormawa;
            $row[] = $keg->nama_keg;
            $row[] = word_limiter($keg->isi_keg, 30);
            $row[] = '<a href="javascript:void(0)" onclick="detail('.$keg->id_ko.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('public/keg_ormawa/dokumentasi/'. $keg->id_ko) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_ko) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->keg_ormawa->get_total_dokumentasi($id_ko);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->keg_ormawa->get_datatables_search_dokumentasi($search, $start, $length, $id_ko);
        } else {
            $list = $this->keg_ormawa->get_datatables_dokumentasi($start, $length, $id_ko);
        }

        if($search !== "") {
            $total_search = $this->keg_ormawa->get_total_search_dokumentasi($search, $id_ko);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/keg_ormawa/'.$dokumentasi->file).'" alt="">';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function detail($id_ko) {
        $keg_ormawa = $this->db->where('id_ko', $id_ko)->get('keg_ormawa')->row();

        $data = [
            'id_ko'       => $keg_ormawa->id_ko,
            'tgl_keg'     => $keg_ormawa->tgl_keg,
            'nama_keg'    => $keg_ormawa->nama_keg,
            'isi_keg'     => $keg_ormawa->isi_keg,
            'nama_ormawa' => $keg_ormawa->nama_ormawa,
        ];

        echo json_encode($data);
    }
}