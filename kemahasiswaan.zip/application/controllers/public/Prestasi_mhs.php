<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Prestasi_mhs extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Prestasi_mhs_model', 'prestasi_mhs');

        $this->halaman = 'prestasi_mhs';
    }

    public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/prestasi_mhs/list',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function dokumentasi($id_pm) {
        $data = [
            'halaman'    => $this->halaman,
            'main'       => 'public/prestasi_mhs/dokumentasi',
            'id_pm' => $id_pm
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_mhs->get_total();
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_mhs->get_datatables_search($search, $start, $length);
        } else {
            $list = $this->prestasi_mhs->get_datatables($start, $length);
        }

        if($search !== "") {
            $total_search = $this->prestasi_mhs->get_total_search($search);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            $fakultas = $this->db->where('id_fakultas', $keg->id_fakultas)->get('fakultas')->row();

            $row = array();
            $row[] = $no;
            $row[] = $fakultas->nama_fakultas;
            $row[] = $keg->tahun;
            $row[] = $keg->juara;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_pm;
            $row[] = word_limiter($keg->deskripsi_pm, 30);
            $row[] = '<a href="javascript:void(0)" onclick="detail('.$keg->id_pm.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('public/prestasi_mhs/dokumentasi/'. $keg->id_pm) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_pm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_mhs->get_total_dokumentasi($id_pm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_mhs->get_datatables_search_dokumentasi($search, $start, $length, $id_pm);
        } else {
            $list = $this->prestasi_mhs->get_datatables_dokumentasi($start, $length, $id_pm);
        }

        if($search !== "") {
            $total_search = $this->prestasi_mhs->get_total_search_dokumentasi($search, $id_pm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/prestasi_mhs/'.$dokumentasi->file).'" alt="">';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function detail($id_pm) {
        $prestasi_mhs = $this->db->where('id_pm', $id_pm)->get('prestasi_mhs')->row();
        $fakultas     = $this->db->where('id_fakultas', $prestasi_mhs->id_fakultas)->get('fakultas')->row();

        $data = [
            'id_pm'        => $prestasi_mhs->id_pm,
            'nama_pm'      => $prestasi_mhs->nama_pm,
            'deskripsi_pm' => $prestasi_mhs->deskripsi_pm,
            'tahun'        => $prestasi_mhs->tahun,
            'tingkat'      => $prestasi_mhs->tingkat,
            'juara'        => $prestasi_mhs->juara,
            'id_fakultas'  => $fakultas->nama_fakultas,
            'tgl_input'    => format_tanggal($prestasi_mhs->tgl_input),
        ];

        echo json_encode($data);
    }
}