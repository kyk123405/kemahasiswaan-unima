<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
		parent::__construct();

        $this->halaman = 'dashboard';
	}
	
	public function index() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/dashboard',
        ];

		$this->load->view('public/layouts/template', $data);
	}
}