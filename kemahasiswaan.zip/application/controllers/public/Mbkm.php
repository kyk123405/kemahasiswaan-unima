<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Mbkm extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Mbkm_model', 'mbkm');
        $this->halaman = 'mbkm';
    }

    public function data($id_jm) {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/mbkm/list',
            'id_jm'   => $id_jm
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function grafik() {
        $data = [
            'halaman' => $this->halaman,
            'main'    => 'public/mbkm/grafik',
        ];

        $this->load->view('public/layouts/template', $data);
    }

    public function ajax_list($id_jm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->mbkm->get_total($id_jm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->mbkm->get_datatables_search($search, $start, $length, $id_jm);
        } else {
            $list = $this->mbkm->get_datatables($start, $length, $id_jm);
        }

        if($search !== "") {
            $total_search = $this->mbkm->get_total_search($search, $id_jm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $mbkm) {
            $fakultas = $this->db->where('id_fakultas', $mbkm->id_fakultas)->get('fakultas')->row();
            $prodi = $this->db->where('id_prodi', $mbkm->id_prodi)->get('prodi')->row();
            $jenis    = $this->db->where('id_jm', $id_jm)->get('jenis_mbkm')->row();

            $row = array();
            $row[] = $no;
            $row[] = $fakultas->nama_fakultas;
            $row[] = $prodi->nama_prodi;
            $row[] = $jenis->nama_jm;
            $row[] = $mbkm->tahun;
            $row[] = $mbkm->jumlah;

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }
}