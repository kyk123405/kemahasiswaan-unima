<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
        $this->halaman = 'dashboard';
	}
	
	public function index() {

        $data = [
			'halaman'      => $this->halaman,
			'main'         => 'dashboard',
			'keg_mhs'      => $this->db->order_by('tgl_keg', 'desc')->get('keg_mhs', 4)->result(),
			'keg_orm'      => $this->db->order_by('tgl_keg', 'desc')->get('keg_ormawa', 4)->result(),
			'prestasi_mhs' => $this->db->order_by('tahun', 'desc')->get('prestasi_mhs', 4)->result(),
			'dokumentasi'  => $this->db->order_by('id_dokumentasi_pm', 'desc')->get('dokumentasi_pm', 6)->result()
        ];

		$this->load->view('layouts/template', $data);
	}

	public function prestasi_mhs($id_pm) {
      $data = [
				'halaman'      => $this->halaman,
				'main'         => 'detail_prestasi_mhs',
				'prestasi_mhs' => $this->db->where('id_pm', $id_pm)->get('prestasi_mhs')->row()
      ];
      $this->load->view('layouts/template', $data);
   }
}