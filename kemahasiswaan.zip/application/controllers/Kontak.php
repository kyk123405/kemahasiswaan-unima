<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kontak extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
        $this->halaman = 'kontak';
	}
	
	public function index() {

        $data = [
          'halaman'   => $this->halaman,
          'main'      => 'kontak',
        ];

		$this->load->view('layouts/template', $data);
	}
}