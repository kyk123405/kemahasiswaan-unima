<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Prestasi_mhs extends Fakultas_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Prestasi_mhs_model', 'prestasi_mhs');
        $this->nama_fakultas = $this->session->userdata('nama_fakultas');
        $this->id_fakultas   = $this->session->userdata('id_fakultas');

        $this->halaman = 'prestasi_mhs';
    }

    public function index() {
        $data = [
            'halaman'     => $this->halaman,
            'main'        => 'fakultas/prestasi_mhs/list',
            'id_fakultas' => $this->id_fakultas
        ];

        $this->load->view('fakultas/layouts/template', $data);
    }

    public function dokumentasi($id_pm) {
        $data = [
            'halaman'     => $this->halaman,
            'main'        => 'fakultas/prestasi_mhs/dokumentasi',
            'id_pm'       => $id_pm,
            'id_fakultas' => $this->id_fakultas
        ];

        $this->load->view('fakultas/layouts/template', $data);
    }

    public function ajax_list() {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_mhs->get_total_fakultas($this->id_fakultas);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_mhs->get_datatables_search_fakultas($search, $start, $length, $this->id_fakultas);
        } else {
            $list = $this->prestasi_mhs->get_datatables_fakultas($start, $length, $this->id_fakultas);
        }

        if($search !== "") {
            $total_search = $this->prestasi_mhs->get_total_search_fakultas($search, $this->id_fakultas);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $keg) {
            $prodi = $this->db->where('id_prodi', $keg->id_prodi)->get('prodi')->row();

            $row = array();
            $row[] = $no;
            $row[] = $prodi->nama_prodi;
            $row[] = $keg->tahun;
            $row[] = $keg->juara;
            $row[] = $keg->tingkat;
            $row[] = $keg->nama_pm;
            $row[] = word_limiter($keg->deskripsi_pm, 30);
            $row[] = '<a href="javascript:void(0)" onclick="edit('.$keg->id_pm.')" class="btn btn-outline-warning btn-circle btn-sm">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus('.$keg->id_pm.')" class="btn btn-outline-danger btn-circle btn-sm">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="detail('.$keg->id_pm.')" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-fw fa-eye"></i> Detail
                      </a>
                      <a href="'.base_url('fakultas/prestasi_mhs/dokumentasi/'. $keg->id_pm) .'" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-fw fa-plus"></i> Dokumentasi
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_dokumentasi($id_pm) {
        $draw   = $_REQUEST['draw'];
        $length = $_REQUEST['length'];
        $start  = $_REQUEST['start'];
        $search = $_REQUEST['search']["value"];

        $total  = $this->prestasi_mhs->get_total_dokumentasi($id_pm);
        $output = array(
            "length"          => $length,
            "draw"            => $draw,
            "recordsTotal"    => $total,
            "recordsFiltered" => $total            
        );

        if ($search !== "") {            
            $list = $this->prestasi_mhs->get_datatables_search_dokumentasi($search, $start, $length, $id_pm);
        } else {
            $list = $this->prestasi_mhs->get_datatables_dokumentasi($start, $length, $id_pm);
        }

        if($search !== "") {
            $total_search = $this->prestasi_mhs->get_total_search_dokumentasi($search, $id_pm);            
            $output = array(                
                "recordsTotal"    => $total_search,
                "recordsFiltered" => $total_search
            );
        }

        $data = array();
        $no = $start + 1;
        foreach ($list->result() as $dokumentasi) {
            
            $row = array();
            $row[] = $no;
            $row[] = '<img src="'.base_url('uploads/prestasi_mhs/'.$dokumentasi->file).'" alt="" width="250px">';
            $row[] = '<a href="javascript:void(0)" onclick="edit_dokumentasi('.$dokumentasi->id_dokumentasi_pm.')" class="btn btn-outline-warning btn-circle btn-m">
                        <i class="fas fa-fw fa-pencil-alt"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="hapus_dokumentasi('.$dokumentasi->id_dokumentasi_pm.')" class="btn btn-outline-danger btn-circle btn-m">
                        <i class="fas fa-fw fa-trash-alt"></i>
                      </a>';

            $data[] = $row;
            $no++;
        }

        $output['data'] = $data;

        echo json_encode($output);
        exit();
    }

    public function ajax_edit($id_pm) {
        $data = $this->prestasi_mhs->where('id_pm', $id_pm)->get();
        echo json_encode($data);
    }

    public function ajax_edit_dokumentasi($id_dokumentasi_pm) {
        $data = $this->db->where('id_dokumentasi_pm', $id_dokumentasi_pm)->get('dokumentasi_pm')->row();
        echo json_encode($data);
    }

    public function ajax_add() {

        $data = [     
            'nama_pm'      => $this->input->post('nama_pm'),
            'deskripsi_pm' => $this->input->post('deskripsi_pm'),
            'id_prodi'     => $this->input->post('id_prodi'),
            'id_fakultas'  => $this->id_fakultas,
            'tingkat'      => $this->input->post('tingkat'),
            'tahun'        => $this->input->post('tahun'),
            'juara'        => $this->input->post('juara'),
            'tgl_input'    => date('Y-m-d H:i:s')
        ];

        $insert = $this->prestasi_mhs->insert($data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_add_dokumentasi() {

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = null;
        } 

        $data = [     
            'id_pm' => $this->input->post('id_pm'),
            'file'      => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $insert = $this->db->insert('dokumentasi_pm', $data);

        if ($insert) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update() {
        $id_pm = $this->input->post('id_pm');
        $prestasi_mhs = $this->db->where('id_pm', $id_pm)->get('prestasi_mhs')->row();

        $data = [           
            'nama_pm'      => $this->input->post('nama_pm'),
            'deskripsi_pm' => $this->input->post('deskripsi_pm'),
            'id_prodi'     => $this->input->post('id_prodi'),
            'id_fakultas'  => $this->id_fakultas,
            'tingkat'      => $this->input->post('tingkat'),
            'tahun'        => $this->input->post('tahun'),
            'juara'        => $this->input->post('juara'),
            'tgl_input'    => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_pm', $id_pm)->update('prestasi_mhs',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_update_dokumentasi() {
        $id_dokumentasi_pm      = $this->input->post('id_dokumentasi_pm');
        $dokumentasi_pm = $this->db->where('id_dokumentasi_pm', $id_dokumentasi_pm)->get('dokumentasi_pm')->row();

        if ( ! empty($_FILES['file']['name'])) {
            $upload = $this->file_upload('file');
            $file = $upload;
        } else {
            $file = $dokumentasi_pm->file;
        }

        $data = [
            'id_pm' => $this->input->post('id_pm'),
            'file'       => $file,
            'tgl_input'  => date('Y-m-d H:i:s')
        ];

        $update = $this->db->where('id_dokumentasi_pm', $id_dokumentasi_pm)->update('dokumentasi_pm',$data);
        
        if ($update) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete($id_pm) {
        $delete = $this->prestasi_mhs->where('id_pm', $id_pm)->delete();

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function ajax_delete_dokumentasi($id_dokumentasi_pm) {
        $delete = $this->db->where('id_dokumentasi_pm', $id_dokumentasi_pm)->delete('dokumentasi_pm');

        if ($delete) {
            echo json_encode(array("status" => TRUE));
        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function detail($id_pm) {
        $prestasi_mhs = $this->db->where('id_pm', $id_pm)->get('prestasi_mhs')->row();
        $fakultas     = $this->db->where('id_fakultas', $prestasi_mhs->id_fakultas)->get('fakultas')->row();
        $prodi        = $this->db->where('id_prodi', $prestasi_mhs->id_prodi)->get('prodi')->row();

        $data = [
            'id_pm'        => $prestasi_mhs->id_pm,
            'nama_pm'      => $prestasi_mhs->nama_pm,
            'deskripsi_pm' => $prestasi_mhs->deskripsi_pm,
            'tahun'        => $prestasi_mhs->tahun,
            'tingkat'      => $prestasi_mhs->tingkat,
            'juara'        => $prestasi_mhs->juara,
            'id_fakultas'  => $fakultas->nama_fakultas,
            'id_prodi'  => $prodi->nama_prodi,
            'tgl_input'    => format_tanggal($prestasi_mhs->tgl_input),
        ];

        echo json_encode($data);
    }

    private function file_upload($gambar) {
        $config['upload_path']   = './uploads/prestasi_mhs/';
        $config['allowed_types'] ='jpg|png|jpeg|JPG|JPEG|PNG';
        $config['max_size']      = 10240;
        //$config['max_width']     = 3920;
        //$config['max_height']    = 7080;
        $config['file_name']     = round(microtime(true) * 1000);

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload($gambar)) {
            $error = $this->upload->display_errors();
 
            $this->session->set_flashdata('error', $this->upload->display_errors('',''));
            $this->session->set_flashdata('penting', true);
            print($error);
        }

        return $this->upload->data('file_name');
    }
}