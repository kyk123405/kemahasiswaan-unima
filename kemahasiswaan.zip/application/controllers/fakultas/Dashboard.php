<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Fakultas_Controller {

	public function __construct() {
		parent::__construct();

        $this->halaman = 'dashboard';
	}
	
	public function index() {
        $data = [
			'halaman'     => $this->halaman,
			'main'        => 'fakultas/dashboard',
			'id_fakultas' => $this->session->userdata('id_fakultas')
        ];

		$this->load->view('fakultas/layouts/template', $data);
	}
}