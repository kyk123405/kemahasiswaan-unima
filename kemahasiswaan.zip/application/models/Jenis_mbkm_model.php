<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis_mbkm_model extends MY_Model {

	protected $table = 'jenis_mbkm';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM jenis_mbkm
				ORDER BY id_jm ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM jenis_mbkm
                WHERE nama_jm LIKE '%$search%'
                ORDER BY id_jm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM jenis_mbkm 
                WHERE nama_jm LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}