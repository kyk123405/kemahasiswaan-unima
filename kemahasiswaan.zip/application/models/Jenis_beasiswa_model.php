<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis_beasiswa_model extends MY_Model {

	protected $table = 'jenis_beasiswa';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM jenis_beasiswa
				ORDER BY id_jb ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM jenis_beasiswa
                WHERE nama_jb LIKE '%$search%'
                ORDER BY id_jb DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM jenis_beasiswa 
                WHERE nama_jb LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}