<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prodi_model extends MY_Model {

	protected $table = 'prodi';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM prodi
				ORDER BY id_prodi ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM prodi
                WHERE nama_prodi LIKE '%$search%'
                OR singkatan LIKE '%$search%'
                OR username LIKE '%$search%'
                ORDER BY id_prodi DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM prodi 
                WHERE nama_prodi LIKE '%$search%'
                OR singkatan LIKE '%$search%'
                OR username LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}