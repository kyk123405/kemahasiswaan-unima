<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mbkm_model extends MY_Model {

	protected $table = 'mbkm';

	function get_datatables($start, $length, $id_jm)
	{
		$sql = "SELECT * 
				FROM mbkm
                WHERE id_jm = '$id_jm'
				ORDER BY id_mbkm ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length, $id_jm) {
        $sql = "SELECT * 
                FROM mbkm b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                JOIN prodi p ON p.id_prodi = b.id_prodi
                WHERE b.id_jm = '$id_jm' 
                AND f.nama_fakultas LIKE '%$search%'
                OR p.nama_prodi LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'
                ORDER BY id_mbkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total($id_jm) {
        $query = $this->db->where('id_jm', $id_jm)->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search, $id_jm) {
        $sql = "SELECT *
                FROM mbkm b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                JOIN prodi p ON p.id_prodi = b.id_prodi
                WHERE b.id_jm = '$id_jm' 
                AND f.nama_fakultas LIKE '%$search%'
                OR p.nama_prodi LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Fakultas

    function get_datatables_fakultas($start, $length, $id_jm, $id_fakultas)
    {
        $sql = "SELECT * 
                FROM mbkm
                WHERE id_jm = '$id_jm'
                AND id_fakultas = '$id_fakultas'
                ORDER BY id_mbkm ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_fakultas($search, $start, $length, $id_jm, $id_fakultas) {
        $sql = "SELECT * 
                FROM mbkm b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                WHERE b.id_jm = '$id_jm' 
                AND id_fakultas = '$id_fakultas'
                OR f.nama_fakultas LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'
                ORDER BY id_mbkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_fakultas($id_jm, $id_fakultas) {
        $query = $this->db->where('id_jm', $id_jm)->where('id_fakultas', $id_fakultas)->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_fakultas($search, $id_jm, $id_fakultas) {
        $sql = "SELECT *
                FROM mbkm b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                WHERE b.id_jm = '$id_jm' 
                AND id_fakultas = '$id_fakultas'
                OR f.nama_fakultas LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Prodi

    function get_datatables_prodi($start, $length, $id_jm, $id_prodi)
    {
        $sql = "SELECT * 
                FROM mbkm
                WHERE id_jm = '$id_jm'
                AND id_prodi = '$id_prodi'
                ORDER BY id_mbkm ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_prodi($search, $start, $length, $id_jm, $id_prodi) {
        $sql = "SELECT * 
                FROM mbkm b
                JOIN prodi f ON f.id_prodi = b.id_prodi
                WHERE b.id_jm = '$id_jm' 
                AND id_prodi = '$id_prodi'
                OR f.nama_prodi LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'
                ORDER BY id_mbkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_prodi($id_jm, $id_prodi) {
        $query = $this->db->where('id_jm', $id_jm)->where('id_prodi', $id_prodi)->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_prodi($search, $id_jm, $id_prodi) {
        $sql = "SELECT *
                FROM mbkm b
                JOIN prodi f ON f.id_prodi = b.id_prodi
                WHERE b.id_jm = '$id_jm' 
                AND id_prodi = '$id_prodi'
                OR f.nama_fakultas LIKE '%$search%'
                OR b.jumlah LIKE '%$search%'
                OR b.tahun LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}