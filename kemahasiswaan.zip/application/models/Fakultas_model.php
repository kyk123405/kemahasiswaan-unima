<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fakultas_model extends MY_Model {

	protected $table = 'fakultas';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM fakultas
				ORDER BY id_fakultas ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM fakultas
                WHERE nama_fakultas LIKE '%$search%'
                OR singkatan LIKE '%$search%'
                ORDER BY id_fakultas DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM fakultas 
                WHERE nama_fakultas LIKE '%$search%'
                OR singkatan LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}