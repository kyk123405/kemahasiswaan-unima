<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beasiswa_model extends MY_Model {

	protected $table = 'beasiswa';

	function get_datatables($start, $length, $id_jb)
	{
		$sql = "SELECT * 
				FROM beasiswa
                WHERE id_jb = '$id_jb'
				ORDER BY id_beasiswa ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length, $id_jb) {
        $sql = "SELECT * 
                FROM beasiswa b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                JOIN prodi p ON p.id_prodi = b.prodi
                WHERE f.nama_fakultas LIKE '%$search%'
                OR p.nama_prodi LIKE '%$search%'
                OR b.nama LIKE '%$search%'
                OR b.nim LIKE '%$search%'
                OR b.tahun LIKE '%$search%'
                AND b.id_jb = '$id_jb'
                ORDER BY id_beasiswa DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total($id_jb) {
        $query = $this->db->where('id_jb', $id_jb)->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search, $id_jb) {
        $sql = "SELECT *
                FROM beasiswa b
                JOIN fakultas f ON f.id_fakultas = b.id_fakultas
                JOIN prodi p ON p.id_prodi = b.prodi
                WHERE b.id_jb = '$id_jb' 
                OR f.nama_fakultas LIKE '%$search%'
                OR p.nama_prodi LIKE '%$search%'
                OR b.nama LIKE '%$search%'
                OR b.nim LIKE '%$search%'
                OR b.tahun LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}