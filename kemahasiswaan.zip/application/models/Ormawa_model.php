<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ormawa_model extends MY_Model {

	protected $table = 'ormawa';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM ormawa
				ORDER BY tahun DESC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM ormawa
                WHERE tahun LIKE '%$search%'
                OR jlh_ormawa LIKE '%$search%'
                ORDER BY id_ormawa DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM ormawa 
                WHERE tahun LIKE '%$search%'
                OR jlh_ormawa LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Fakultas

    function get_datatables_fakultas($start, $length, $id_fakultas)
    {
        $sql = "SELECT * 
                FROM ormawa
                WHERE id_fakultas = '$id_fakultas'
                ORDER BY tahun DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_fakultas($search, $start, $length, $id_fakultas) {
        $sql = "SELECT * 
                FROM ormawa
                WHERE tahun LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR jlh_ormawa LIKE '%$search%'
                ORDER BY id_ormawa DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_fakultas($id_fakultas) {
        $query = $this->db->select("COUNT(*) as num")->where('id_fakultas', $id_fakultas)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_fakultas($search, $id_fakultas) {
        $sql = "SELECT *
                FROM ormawa 
                WHERE tahun LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR jlh_ormawa LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Prodi

    function get_datatables_prodi($start, $length, $id_prodi)
    {
        $sql = "SELECT * 
                FROM ormawa
                WHERE id_prodi = '$id_prodi'
                ORDER BY tahun DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_prodi($search, $start, $length, $id_prodi) {
        $sql = "SELECT * 
                FROM ormawa
                WHERE tahun LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR jlh_ormawa LIKE '%$search%'
                ORDER BY id_ormawa DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_prodi($id_prodi) {
        $query = $this->db->select("COUNT(*) as num")->where('id_prodi', $id_prodi)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_prodi($search, $id_prodi) {
        $sql = "SELECT *
                FROM ormawa 
                WHERE tahun LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR jlh_ormawa LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}