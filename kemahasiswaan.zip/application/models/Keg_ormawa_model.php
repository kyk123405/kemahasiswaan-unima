<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keg_ormawa_model extends MY_Model {

	protected $table = 'keg_ormawa';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM keg_ormawa
				ORDER BY tgl_keg DESC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM keg_ormawa
                WHERE nama_keg LIKE '%$search%'
                OR isi_keg LIKE '%$search%'
                OR nama_ormawa LIKE '%$search%'
                OR tgl_keg LIKE '%$search%'
                ORDER BY id_ko DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM keg_ormawa 
                WHERE nama_keg LIKE '%$search%'
                OR isi_keg LIKE '%$search%'
                OR nama_ormawa LIKE '%$search%'
                OR tgl_keg LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Fakultas
    function get_datatables_fakultas($start, $length, $id_fakultas)
    {
        $sql = "SELECT * 
                FROM keg_ormawa
                WHERE id_fakultas = '$id_fakultas'
                ORDER BY tgl_keg DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_fakultas($search, $start, $length, $id_fakultas) {
        $sql = "SELECT * 
                FROM keg_ormawa
                WHERE nama_keg LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR isi_keg LIKE '%$search%'
                OR nama_ormawa LIKE '%$search%'
                OR tgl_keg LIKE '%$search%'
                ORDER BY id_ko DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_fakultas($id_fakultas) {
        $query = $this->db->select("COUNT(*) as num")->where('id_fakultas', $id_fakultas)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_fakultas($search, $id_fakultas) {
        $sql = "SELECT *
                FROM keg_ormawa 
                WHERE nama_keg LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR isi_keg LIKE '%$search%'
                OR nama_ormawa LIKE '%$search%'
                OR tgl_keg LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Dokumentasi

    function get_datatables_dokumentasi($start, $length, $id_ko)
    {
        $sql = "SELECT * 
                FROM dokumentasi_ormawa
                WHERE id_ko = '$id_ko' 
                ORDER BY id_do ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_dokumentasi($search, $start, $length, $id_ko) {
        $sql = "SELECT * 
                FROM dokumentasi_ormawa
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'
                ORDER BY id_do DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_dokumentasi($id_ko) {
        $query = $this->db->where('id_ko', $id_ko)->select("COUNT(*) as num")->get('dokumentasi_ormawa');
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_dokumentasi($search, $id_ko) {
        $sql = "SELECT *
                FROM dokumentasi_ormawa 
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}