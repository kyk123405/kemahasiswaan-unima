<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keg_mhs_model extends MY_Model {

	protected $table = 'keg_mhs';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM keg_mhs
				ORDER BY tgl_keg ASC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM keg_mhs
                WHERE nama_keg LIKE '%$search%'
                OR isi_keg LIKE '%$search%'
                ORDER BY id_keg_mhs DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM keg_mhs 
                WHERE nama_keg LIKE '%$search%'
                OR isi_keg LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Dokumentasi

    function get_datatables_dokumentasi($start, $length, $id_keg_mhs)
    {
        $sql = "SELECT * 
                FROM dokumentasi_keg_mhs
                WHERE id_keg_mhs = '$id_keg_mhs' 
                ORDER BY id_dok_keg_mhs ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_dokumentasi($search, $start, $length, $id_keg_mhs) {
        $sql = "SELECT * 
                FROM dokumentasi_keg_mhs
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'
                ORDER BY id_dok_keg_mhs DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_dokumentasi($id_keg_mhs) {
        $query = $this->db->where('id_keg_mhs', $id_keg_mhs)->select("COUNT(*) as num")->get('dokumentasi_keg_mhs');
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_dokumentasi($search, $id_keg_mhs) {
        $sql = "SELECT *
                FROM dokumentasi_keg_mhs 
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}