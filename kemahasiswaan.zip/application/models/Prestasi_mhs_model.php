<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prestasi_mhs_model extends MY_Model {

	protected $table = 'prestasi_mhs';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM prestasi_mhs
				ORDER BY id_pm DESC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM prestasi_mhs pm
                JOIN fakultas f ON f.id_fakultas = pm.id_fakultas
                WHERE pm.nama_pm LIKE '%$search%'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.id_fakultas LIKE '%$search%'
                ORDER BY pm.id_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM prestasi_mhs pm
                JOIN fakultas f ON f.id_fakultas = pm.id_fakultas
                WHERE pm.nama_pm LIKE '%$search%'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.id_fakultas LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Fakultas

    function get_datatables_fakultas($start, $length, $id_fakultas)
    {
        $sql = "SELECT * 
                FROM prestasi_mhs
                WHERE id_fakultas = '$id_fakultas'
                ORDER BY id_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_fakultas($search, $start, $length, $id_fakultas) {
        $sql = "SELECT * 
                FROM prestasi_mhs pm
                JOIN fakultas f ON f.id_fakultas = pm.id_fakultas
                WHERE pm.nama_pm LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.id_fakultas LIKE '%$search%'
                ORDER BY pm.id_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_fakultas($id_fakultas) {
        $query = $this->db->select("COUNT(*) as num")->where('id_fakultas', $id_fakultas)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_fakultas($search) {
        $sql = "SELECT *
                FROM prestasi_mhs pm
                JOIN fakultas f ON f.id_fakultas = pm.id_fakultas
                WHERE pm.nama_pm LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.id_fakultas LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Prodi

    function get_datatables_prodi($start, $length, $id_prodi)
    {
        $sql = "SELECT * 
                FROM prestasi_mhs
                WHERE id_prodi = '$id_prodi'
                ORDER BY id_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_prodi($search, $start, $length, $id_prodi) {
        $sql = "SELECT * 
                FROM prestasi_mhs pm
                JOIN prodi f ON f.id_prodi = pm.id_prodi
                WHERE pm.nama_pm LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.nama_prodi LIKE '%$search%'
                ORDER BY pm.id_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_prodi($id_prodi) {
        $query = $this->db->select("COUNT(*) as num")->where('id_prodi', $id_prodi)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_prodi($search) {
        $sql = "SELECT *
                FROM prestasi_mhs pm
                JOIN prodi f ON f.id_prodi = pm.id_prodi
                WHERE pm.nama_pm LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR pm.deskripsi_pm LIKE '%$search%'
                OR pm.tahun LIKE '%$search%'
                OR pm.tingkat LIKE '%$search%'
                OR pm.juara LIKE '%$search%'
                OR f.nama_prodi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Dokumentasi

    function get_datatables_dokumentasi($start, $length, $id_pm)
    {
        $sql = "SELECT * 
                FROM dokumentasi_pm
                WHERE id_pm = '$id_pm' 
                ORDER BY id_dokumentasi_pm ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_dokumentasi($search, $start, $length, $id_pm) {
        $sql = "SELECT * 
                FROM dokumentasi_pm
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'
                ORDER BY id_dokumentasi_pm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_dokumentasi($id_pm) {
        $query = $this->db->where('id_pm', $id_pm)->select("COUNT(*) as num")->get('dokumentasi_pm');
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_dokumentasi($search, $id_pm) {
        $sql = "SELECT *
                FROM dokumentasi_pm 
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}