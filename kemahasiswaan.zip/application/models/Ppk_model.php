<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ppk_model extends MY_Model {

	protected $table = 'ppk';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM ppk
				ORDER BY id_ppk DESC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM ppk
                WHERE tahun LIKE '%$search%'
                OR jumlah LIKE '%$search%'
                ORDER BY id_ppk DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM ppk ppk
                WHERE tahun LIKE '%$search%'
                OR jumlah LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
    
    //Dokumentasi

    function get_datatables_dokumentasi($start, $length, $id_ppk)
    {
        $sql = "SELECT * 
                FROM dokumentasi_ppk
                WHERE id_ppk = '$id_ppk' 
                ORDER BY id_dp ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_dokumentasi($search, $start, $length, $id_ppk) {
        $sql = "SELECT * 
                FROM dokumentasi_ppk
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'
                ORDER BY id_dp DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_dokumentasi($id_ppk) {
        $query = $this->db->where('id_ppk', $id_ppk)->select("COUNT(*) as num")->get('dokumentasi_ppk');
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_dokumentasi($search, $id_ppk) {
        $sql = "SELECT *
                FROM dokumentasi_ppk 
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}