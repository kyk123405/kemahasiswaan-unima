<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sambutan_model extends MY_Model {

	protected $table = 'sambutan';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM sambutan
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM sambutan
                WHERE isi LIKE '%$search%'
                OR nama LIKE '%$search%'
                OR jabatan LIKE '%$search%'
                ORDER BY id_sambutan DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM sambutan 
                WHERE isi LIKE '%$search%'
                OR nama LIKE '%$search%'
                OR jabatan LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}