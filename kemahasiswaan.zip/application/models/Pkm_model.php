<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pkm_model extends MY_Model {

	protected $table = 'pkm';

	function get_datatables($start, $length)
	{
		$sql = "SELECT * 
				FROM pkm
				ORDER BY id_pkm DESC
				LIMIT $start, $length";
		return $this->db->query($sql);
	}

	function get_datatables_search($search, $start, $length) {
        $sql = "SELECT * 
                FROM pkm
                WHERE nama_pkm LIKE '%$search%'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'
                ORDER BY id_pkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total() {
        $query = $this->db->select("COUNT(*) as num")->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search($search) {
        $sql = "SELECT *
                FROM pkm pkm
                WHERE nama_pkm LIKE '%$search%'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Fakultas

    function get_datatables_fakultas($start, $length, $id_fakultas)
    {
        $sql = "SELECT * 
                FROM pkm
                WHERE id_fakultas = '$id_fakultas'
                ORDER BY id_pkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_fakultas($search, $start, $length, $id_fakultas) {
        $sql = "SELECT * 
                FROM pkm
                WHERE nama_pkm LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'
                ORDER BY id_pkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_fakultas($id_fakultas) {
        $query = $this->db->select("COUNT(*) as num")->where('id_fakultas', $id_fakultas)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_fakultas($search, $id_fakultas) {
        $sql = "SELECT *
                FROM pkm pkm
                WHERE nama_pkm LIKE '%$search%'
                AND id_fakultas = '$id_fakultas'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Prodi

    function get_datatables_prodi($start, $length, $id_prodi)
    {
        $sql = "SELECT * 
                FROM pkm
                WHERE id_prodi = '$id_prodi'
                ORDER BY id_pkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_prodi($search, $start, $length, $id_prodi) {
        $sql = "SELECT * 
                FROM pkm
                WHERE nama_pkm LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'
                ORDER BY id_pkm DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_prodi($id_prodi) {
        $query = $this->db->select("COUNT(*) as num")->where('id_prodi', $id_prodi)->get($this->table);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_prodi($search, $id_prodi) {
        $sql = "SELECT *
                FROM pkm pkm
                WHERE nama_pkm LIKE '%$search%'
                AND id_prodi = '$id_prodi'
                OR deskripsi_pkm LIKE '%$search%'
                OR tahun LIKE '%$search%'
                OR tingkat LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }

    //Dokumentasi

    function get_datatables_dokumentasi($start, $length, $id_pkm)
    {
        $sql = "SELECT * 
                FROM dokumentasi_pkm
                WHERE id_pkm = '$id_pkm' 
                ORDER BY id_dp ASC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    function get_datatables_search_dokumentasi($search, $start, $length, $id_pkm) {
        $sql = "SELECT * 
                FROM dokumentasi_pkm
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'
                ORDER BY id_dp DESC
                LIMIT $start, $length";
        return $this->db->query($sql);
    }

    public function get_total_dokumentasi($id_pkm) {
        $query = $this->db->where('id_pkm', $id_pkm)->select("COUNT(*) as num")->get('dokumentasi_pkm');
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }

    public function get_total_search_dokumentasi($search, $id_pkm) {
        $sql = "SELECT *
                FROM dokumentasi_pkm 
                WHERE file LIKE '%$search%'
                OR deskripsi LIKE '%$search%'";
        return $this->db->query($sql)->num_rows();
    }
}