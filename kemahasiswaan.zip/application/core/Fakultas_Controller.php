<?php
class Fakultas_Controller extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        
        $level    = $this->session->userdata('level');
        $is_login = $this->session->userdata('is_login');

        if (!$is_login) {
            redirect('fakultas/login_fakultas');
            return;
        }

        if ($level !== 'fakultas') {
            redirect(site_url('fakultas/login_fakultas'));
            return;
        }
    }
}
