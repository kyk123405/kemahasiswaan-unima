<script>
    var url_list   = "<?= site_url('admin/keg_mhs/ajax_list'); ?>";
    var url_edit   = "<?= site_url('admin/keg_mhs/ajax_edit/'); ?>";
    var url_add    = "<?= site_url('admin/keg_mhs/ajax_add/'); ?>";
    var url_update = "<?= site_url('admin/keg_mhs/ajax_update/'); ?>";
    var url_delete = "<?= site_url('admin/keg_mhs/ajax_delete/'); ?>";
    var url_detail = "<?= site_url('admin/keg_mhs/detail/'); ?>";
</script>
<script src="<?= base_url('assets/script/keg_mhs.js'); ?>"></script>

<div class="notifikasi"></div>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Daftar Kegiatan Kemahasiswaan Universitas Negeri Manado</h1>
    <p class="mb-4"></p>

    <div class="card shadow mb-4 border-bottom-warning ">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <a href="javascript:void(0)" onclick="tambah()" class="btn btn-outline-primary btn-sm">
                   <i class="fas fa-fw fa-plus"></i>
                </a>
                <a href="javascript:void(0)" onclick="reload_table()" class="btn btn-outline-danger btn-sm">
                   <i class="fas fa-fw fa-exchange-alt"></i>
                </a>                
            </h6>            
        </div>
        <div class="card-body">
            <div class="table-responsive">                
                <table class="table table-hover" id="myTable2" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="text-align: center; width: 10%;">Cover</th>
                            <th style="text-align: center;">Tanggal Kegiatan</th>
                            <th style="text-align: center;">Nama Kegiatan</th>
                            <th style="text-align: center;">Isi Kegiatan</th>
                            <th style="width: 25%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>    
</div>

<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">                
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body form">
                <form action="#" id="form">
                    <input type="hidden" name="id_keg_mhs" />

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="tgl_keg">Tanggal Kegiatan</label>
                        <div class="col-sm-9">
                            <input type="date" name="tgl_keg" id="tgl_keg" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="nama_keg">Nama Kegiatan</label>
                        <div class="col-sm-9">
                            <input type="text" name="nama_keg" id="nama_keg" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="isi_keg">Isi Kegiatan</label>
                        <div class="col-sm-9">
                            <textarea name="isi_keg" id="isi_keg" class="form-control richtext"></textarea>
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="cover">Cover</label>
                        <div class="col-sm-9">
                            <input type="file" name="cover" id="cover" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="simpan()" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal_detail" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body form">
                <div class="form-group text-left">
                    <table class="table">
                        <tr>
                            <td width="25%">Tanggal Kegiatan</td>
                            <td>
                                <b><div id="tgl_keg"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <td width="25%">Nama Kegiatan</td>
                            <td>
                                <b><div id="nama_keg"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <td width="25%">Isi Kegiatan</td>
                            <td>
                                <b><div id="isi_keg"></div></b>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Kembali</button>
            </div>
        </div>
    </div>
</div>