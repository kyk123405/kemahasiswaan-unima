<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <b>UNIMA</b> <?= date('Y') ?> | KYK</span>
        </div>
    </div>
</footer>