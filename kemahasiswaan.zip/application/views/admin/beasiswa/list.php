<script>
    var url_list   = "<?= site_url('admin/beasiswa/ajax_list/'.$id_jb); ?>";
    var url_edit   = "<?= site_url('admin/beasiswa/ajax_edit/'); ?>";
    var url_add    = "<?= site_url('admin/beasiswa/ajax_add/'); ?>";
    var url_update = "<?= site_url('admin/beasiswa/ajax_update/'); ?>";
    var url_delete = "<?= site_url('admin/beasiswa/ajax_delete/'); ?>";
    var url_detail = "<?= site_url('admin/beasiswa/detail/'); ?>";
</script>
<script src="<?= base_url('assets/script/beasiswa.js'); ?>"></script>

<?php  
    $jenis = $this->db->where('id_jb', $id_jb)->get('jenis_beasiswa')->row();
?>

<div class="notifikasi"></div>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Data Jumlah Penerima Beasiswa <?= $jenis->nama_jb ?> Universitas Negeri Manado</h1>
    <p class="mb-4"></p>

    <div class="card shadow mb-4 border-bottom-warning ">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <a href="javascript:void(0)" onclick="tambah()" class="btn btn-outline-primary btn-sm">
                   <i class="fas fa-fw fa-plus"></i>
                </a>
                <a href="javascript:void(0)" onclick="reload_table()" class="btn btn-outline-danger btn-sm">
                   <i class="fas fa-fw fa-exchange-alt"></i>
                </a>                
            </h6>            
        </div>
        <div class="card-body">
            <div class="table-responsive">                
                <table class="table table-hover" id="myTable2" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="text-align: center;">Tahun</th>
                            <th style="text-align: center;">NIM</th>
                            <th style="text-align: center;">Nama</th>
                            <th style="text-align: center;">Jur/Prodi</th>
                            <th style="text-align: center;">Fakultas</th>
                            <th style="width: 15%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>    
</div>

<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">                
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body form">
                <form action="#" id="form">
                    <input type="hidden" name="id_beasiswa" />
                    <input type="hidden" name="id_jb" value="<?= $id_jb ?>" />
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="tahun">Tahun</label>
                        <div class="col-sm-9">
                            <input type="number" name="tahun" id="tahun" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="id_fakultas">Jur/Prodi</label>
                        <div class="col-sm-9">
                            <?php
                               $dropdown = getDropdownList('prodi', ['id_prodi','nama_prodi']);
                               echo form_dropdown('prodi', $dropdown, 'prodi', 'class="form-control"');
                            ?>
                            <?php if (form_error('prodi')) { ?>
                                <label id="prodi" class="error" for="prodi" style="padding-top: 6px; font-size: 9pt">
                                    <?= form_error('prodi'); ?>
                                </label>
                            <?php } ?> 
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="nim">NIM</label>
                        <div class="col-sm-9">
                            <input type="number" name="nim" id="nim" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="nama">Nama</label>
                        <div class="col-sm-9">
                            <input type="text" name="nama" id="nama" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="simpan()" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>