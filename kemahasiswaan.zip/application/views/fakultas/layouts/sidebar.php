<?php
    $level = $this->session->userdata('level');
?>

<ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
        <div class="sidebar-brand-icon">
            <img class="img-profile" src="<?= base_url('assets/img/logo.png') ?>" width="40px" height="40px">
        </div>
        <div class="sidebar-brand-text mx-3"><b class="text-sm font-weight-bold text-uppercase mb-1">UNIMA</b></div>
    </a>
    
    <hr class="sidebar-divider my-0">
    
    <li class="nav-item <?= ($halaman == 'dashboard') ? 'active' : ''; ?>">
        <a class="nav-link" href="<?= site_url('fakultas/dashboard') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        MAIN MENU
    </div>

    <li class="nav-item <?= ($halaman == 'prestasi_mhs') ? 'active' : ''; ?>">
        <a class="nav-link" href="<?= site_url('fakultas/prestasi_mhs') ?>">
            <i class="fas fa-fw fa-medal"></i>
            <span>Prestasi Mahasiswa</span>
        </a>
    </li>

    <li class="nav-item <?= ($halaman == 'ormawa' || $halaman == 'keg_ormawa') ? 'active' : ''; ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUser"
            aria-expanded="true" aria-controls="collapseUser">
            <i class="fas fa-fw fa-sitemap"></i>
            <span>ORMAWA</span>
        </a>
        <div id="collapseUser" class="collapse <?= ($halaman == 'ormawa' || $halaman == 'keg_ormawa') ? 'show' : ''; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item  <?= ($halaman == 'ormawa') ? 'active' : ''; ?>" href="<?= base_url('fakultas/ormawa') ?>">Jumlah ORMAWA</a>
                <a class="collapse-item  <?= ($halaman == 'keg_ormawa') ? 'active' : ''; ?>" href="<?= base_url('fakultas/keg_ormawa') ?>">Kegiatan ORMAWA</a>
            </div>
        </div>
    </li> 

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMbkm"
            aria-expanded="true" aria-controls="collapseMbkm">
            <i class="fas fa-fw fa-window-restore"></i>
            <span>MBKM</span>
        </a>
        <?php  
            $jenis = $this->db->get('jenis_mbkm')->result();
        ?>
        <div id="collapseMbkm" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php foreach ($jenis as $jenis) { ?>
                    <a class="collapse-item" href="<?= base_url('fakultas/mbkm/data/'.$jenis->id_jm) ?>"><?= $jenis->nama_jm ?></a>
                <?php } ?>
            </div>
        </div>
    </li>

    <li class="nav-item <?= ($halaman == 'prestasi_talenta') ? 'active' : ''; ?>">
        <a class="nav-link" href="<?= site_url('fakultas/prestasi_talenta') ?>">
            <i class="fas fa-fw fa-star"></i>
            <span>Prestasi Talenta</span>
        </a>
    </li>

    <li class="nav-item <?= ($halaman == 'pkm') ? 'active' : ''; ?>">
        <a class="nav-link" href="<?= site_url('fakultas/pkm') ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>PKM/PPK ORMAWA</span>
        </a>
    </li>
    
    <hr class="sidebar-divider d-none d-md-block">    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>