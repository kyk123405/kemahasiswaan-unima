<?php  
    $prodi          = $this->db->where('id_fakultas', $id_fakultas)->get('prodi')->result();
    $jenis          = $this->db->get('jenis_beasiswa')->result();
    $jenis_mbkm        = $this->db->get('jenis_mbkm')->result();
    $prodi_prestasi = $this->db->where('id_fakultas', $id_fakultas)->get('prodi')->result();
?>

<style type="text/css">
    .highcharts-figure,
    .highcharts-data-table table {
      min-width: 460px;
      max-width: 1000px;
      margin: 1em auto;
    }

    #container {
      height: 400px;
    }

    .highcharts-data-table table {
      font-family: Verdana, sans-serif;
      border-collapse: collapse;
      border: 1px solid #ebebeb;
      margin: 10px auto;
      text-align: left;
      width: 100%;
      max-width: 1000px;
    }

    .highcharts-data-table caption {
      padding: 1em 0;
      font-size: 1.2em;
      color: #555;
    }

    .highcharts-data-table th {
      font-weight: 600;
      padding: 0.5em;
    }

    .highcharts-data-table td,
    .highcharts-data-table th,
    .highcharts-data-table caption {
      padding: 0.5em;
    }

    .highcharts-data-table thead tr,
    .highcharts-data-table tr:nth-child(even) {
      background: #f8f8f8;
    }

    .highcharts-data-table tr:hover {
      background: #f1f7ff;
    }

    hr {
        color: black;
    }

    .buttons {
        min-width: 310px;
        text-align: center;
        margin: 1rem 0;
        font-size: 0;
    }

    .buttons button {
        cursor: pointer;
        border: 1px solid silver;
        border-right-width: 0;
        background-color: #f8f8f8;
        font-size: 1rem;
        padding: 0.5rem;
        transition-duration: 0.3s;
        margin: 0;
    }

    .buttons button:first-child {
        border-top-left-radius: 0.3em;
        border-bottom-left-radius: 0.3em;
    }

    .buttons button:last-child {
        border-top-right-radius: 0.3em;
        border-bottom-right-radius: 0.3em;
        border-right-width: 1px;
    }

    .buttons button:hover {
        color: white;
        background-color: rgb(158 159 163);
        outline: none;
    }

    .buttons button.active {
        background-color: #0051b4;
        color: white;
    }
</style>

<div class="container-fluid">    
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>        
    </div>

    <div class="row">
        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA PRESTASI MAHASISWA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6">
                            <figure class="highcharts-figure">
                              <div id="prestasi_tahun"></div>
                            </figure>
                        </div>
                        <div class="col-xl-4">
                            <figure class="highcharts-figure">
                              <div id="prestasi_tingkat"></div>
                            </figure>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="container"></div>
                            </figure>
                            <hr>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="prestasi_juara"></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA BEASISWA MAHASISWA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="beasiswa_jenis"></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA MBKM UNIMA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="mbkm_fakultas"></div>
                            </figure>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="mbkm_jenis"></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA ORMAWA UNIMA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="ormawa"></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA PRESTASI TALENTA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6">
                            <figure class="highcharts-figure">
                              <div id="prestasi_talenta_tahun"></div>
                            </figure>
                        </div>
                        <div class="col-xl-4">
                            <figure class="highcharts-figure">
                              <div id="prestasi_talenta_tingkat"></div>
                            </figure>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="prestasi_talenta"></div>
                            </figure>
                            <hr>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="prestasi_talenta_juara"></div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-dark" style="font-size: 16pt;">DATA PKM/PPK ORMAWA UNIMA</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="pkm"></div>
                            </figure>
                        </div>
                        <div class="col-xl-12">
                            <figure class="highcharts-figure">
                              <div id="pkm_prodi"></div>
                            </figure>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php  
    $tahun         = $this->db->group_by('tahun')->get('prestasi_mhs')->result();
    $tahun_ormawa  = $this->db->group_by('tahun')->get('ormawa')->result();
    $tahun_pkm     = $this->db->group_by('tahun')->get('pkm')->result();
    $tahun_talenta = $this->db->group_by('tahun')->get('prestasi_talenta')->result();
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<!-- Grafik PKM Tahun -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('pkm', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah PKM/PPK ORMAWA UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tahun',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun_pkm as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('pkm')->result();
            ?>
            
                {
                    name: 'Tahun',
                    data: 
                    [
                        <?php foreach ($prestasi as $key) { ?>
                            <?php  
                                $sql_target   = "SELECT COUNT(id_pkm) AS jlh_pkm
                                                 FROM pkm
                                                 WHERE tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pkm;
                                }
                            ?>
                            <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
        ]
    });
</script>

<!-- Grafik Prestasi Tahun -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_tahun', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tahun',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('prestasi_mhs')->result();
            ?>
            
                {
                    name: 'Tahun',
                    data: 
                    [
                        <?php foreach ($prestasi as $key) { ?>
                            <?php  
                                $sql_target   = "SELECT COUNT(id_pm) AS jlh_pm
                                                 FROM prestasi_mhs
                                                 WHERE tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pm;
                                }
                            ?>
                            <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
        ]
    });
</script>

<!-- Grafik Prestasi Juara -->
<script src="https://code.highcharts.com/themes/grid-light.js"></script>
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_juara', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Peringkat',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('juara')->get('prestasi_mhs')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: 'Juara <?php echo $key->juara ?>',
                    data: 
                    [
                        <?php  
                            foreach ($tahun as $row) {
                                $sql_target   = "SELECT COUNT(id_pm) AS jlh_pm
                                                 FROM prestasi_mhs
                                                 WHERE tahun = '$row->tahun'
                                                 AND juara = '$key->juara'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pm;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik Prestasi Tingkat -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_tingkat', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tingkat',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tingkat')->get('prestasi_mhs')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: 'Tingkat <?php echo $key->tingkat ?>',
                    data: 
                    [
                        <?php  
                            foreach ($tahun as $row) {
                                $sql_target   = "SELECT COUNT(id_pm) AS jlh_pm
                                                 FROM prestasi_mhs
                                                 WHERE tahun = '$row->tahun'
                                                 AND tingkat = '$key->tingkat'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pm;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik Beasiswa Jenis Beasiswa -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('beasiswa_jenis', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Beasiswa UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jenis Beasiswa',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($jenis as $row) { ?>
                    '<?php echo $row->nama_jb ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Jenis Beasiswa'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $beasiswa = $this->db->group_by('tahun')->get('beasiswa')->result();
            ?>
            <?php foreach ($beasiswa as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($jenis as $row) {
                                $sql_target   = "SELECT SUM(jumlah) AS jlh_beasiswa
                                                 FROM beasiswa
                                                 WHERE id_jb = '$row->id_jb'
                                                 AND tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    if (empty($query_target->jlh_beasiswa)) {
                                        $target_total = '0';
                                    } else {
                                        $target_total = $query_target->jlh_beasiswa;
                                    }
                                    
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik MBKM Jenis MBKM -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('mbkm_jenis', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah MBKM UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jenis MBKM',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($jenis_mbkm as $row) { ?>
                    '<?php echo $row->nama_jm ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Jenis MBKM'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $mbkm = $this->db->group_by('tahun')->where('id_fakultas', $id_fakultas)->get('mbkm')->result();
            ?>
            <?php foreach ($mbkm as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($jenis_mbkm as $row) {
                                $sql_target   = "SELECT SUM(jumlah) AS jlh_mbkm
                                                 FROM mbkm
                                                 WHERE id_jm = '$row->id_jm'
                                                 AND tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    if (empty($query_target->jlh_mbkm)) {
                                        $target_total = '0';
                                    } else {
                                        $target_total = $query_target->jlh_mbkm;
                                    }
                                    
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik MBKM Fakultas -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('mbkm_fakultas', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah MBKM UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jur/Prodi',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($prodi as $row) { ?>
                    '<?php echo $row->singkatan ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Jur/Prodi'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $mbkm = $this->db->group_by('tahun')->where('id_fakultas', $id_fakultas)->get('mbkm')->result();
            ?>
            <?php foreach ($mbkm as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($prodi as $row) {
                                $sql_target   = "SELECT SUM(jumlah) AS jlh_mbkm
                                                 FROM mbkm
                                                 WHERE id_prodi = '$row->id_prodi'
                                                 AND tahun = '$key->tahun'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_mbkm;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<script src="https://code.highcharts.com/themes/brand-dark.js"></script>
<!-- Grafik ORMAWA Tahun -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('ormawa', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah ORMAWA UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tahun',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun_ormawa as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('ormawa')->result();
            ?>
            
                {
                    name: 'Tahun',
                    data: 
                    [
                        <?php foreach ($prestasi as $key) { ?>
                            <?php  
                                $sql_target   = "SELECT SUM(jlh_ormawa) AS jlh_ormawa
                                                 FROM ormawa
                                                 WHERE tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_ormawa;
                                }
                            ?>
                            <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
        ]
    });
</script>

<!-- Grafik Prestasi Talenta Tahun -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_talenta_tahun', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi Talenta UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tahun',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun_talenta as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('prestasi_talenta')->result();
            ?>
            
                {
                    name: 'Tahun',
                    data: 
                    [
                        <?php foreach ($prestasi as $key) { ?>
                            <?php  
                                $sql_target   = "SELECT COUNT(id_pt) AS jlh_pt
                                                 FROM prestasi_talenta
                                                 WHERE tahun = '$key->tahun'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pt;
                                }
                            ?>
                            <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
        ]
    });
</script>

<!-- Grafik Prestasi Talenta Juara -->
<script src="https://code.highcharts.com/themes/brand-light.js"></script>
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_talenta_juara', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Peringkat',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun_talenta as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('juara')->get('prestasi_talenta')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: 'Juara <?php echo $key->juara ?>',
                    data: 
                    [
                        <?php  
                            foreach ($tahun_talenta as $row) {
                                $sql_target   = "SELECT COUNT(id_pt) AS jlh_pt
                                                 FROM prestasi_talenta
                                                 WHERE tahun = '$row->tahun'
                                                 AND juara = '$key->juara'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pt;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik Prestasi Talenta Tingkat -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_talenta_tingkat', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi Talenta UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Tingkat',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($tahun_talenta as $row) { ?>
                    '<?php echo $row->tahun ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Tahun'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tingkat')->get('prestasi_talenta')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: 'Tingkat <?php echo $key->tingkat ?>',
                    data: 
                    [
                        <?php  
                            foreach ($tahun_talenta as $row) {
                                $sql_target   = "SELECT COUNT(id_pt) AS jlh_pt
                                                 FROM prestasi_talenta
                                                 WHERE tahun = '$row->tahun'
                                                 AND tingkat = '$key->tingkat'
                                                 AND id_fakultas = '$id_fakultas'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pt;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik Prestasi Prodi -->
<script src="https://code.highcharts.com/themes/sand-signika.js"></script>
<script type="text/javascript">
    "use strict";
    Highcharts.chart('container', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jur/Prodi',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($prodi as $row) { ?>
                    '<?php echo $row->nama_prodi ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Prodi'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('prestasi_mhs')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($prodi as $row) {
                                $sql_target   = "SELECT COUNT(id_pm) AS jlh_pm
                                                 FROM prestasi_mhs
                                                 WHERE id_prodi = '$row->id_prodi'
                                                 AND tahun = '$key->tahun'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pm;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik Prestasi Talenta Prodi -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('prestasi_talenta', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah Prestasi Talenta UNIMA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jur/Prodi',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($prodi as $row) { ?>
                    '<?php echo $row->nama_prodi ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Fakultas'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $prestasi = $this->db->group_by('tahun')->get('prestasi_talenta')->result();
            ?>
            <?php foreach ($prestasi as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($prodi as $row) {
                                $sql_target   = "SELECT COUNT(id_pt) AS jlh_pt
                                                 FROM prestasi_talenta
                                                 WHERE id_prodi = '$row->id_prodi'
                                                 AND tahun = '$key->tahun'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pt;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>

<!-- Grafik PKM Prodi -->
<script type="text/javascript">
    "use strict";
    Highcharts.chart('pkm_prodi', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Grafik Data Jumlah PKM/PPK ORMAWA',
            align: 'center'
        },
        subtitle: {
            text:
                'Berdasarkan Jur/Prodi',
            align: 'center'
        },
        xAxis: {
            categories: [
                <?php foreach ($prodi as $row) { ?>
                    '<?php echo $row->nama_prodi ?>',
                <?php } ?>
            ],
            crosshair: true,
            accessibility: {
                description: 'Jur/Prodi'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ''
            }
        },
        tooltip: {
            valueSuffix: ''
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [
            <?php  
                $pkm = $this->db->group_by('tahun')->get('pkm')->result();
            ?>
            <?php foreach ($pkm as $key) { ?>
                {
                    name: '<?php echo $key->tahun ?>',
                    data: 
                    [
                        <?php  
                            foreach ($prodi as $row) {
                                $sql_target   = "SELECT COUNT(id_pkm) AS jlh_pt
                                                 FROM pkm
                                                 WHERE id_prodi = '$row->id_prodi'
                                                 AND tahun = '$key->tahun'";
                                $query_target = $this->db->query($sql_target)->result();

                                $target_total = 0;
                                foreach ($query_target as $query_target) {
                                    $target_total = $query_target->jlh_pt;
                                }
                        ?>
                        <?php echo $target_total ?>,
                        <?php } ?>
                    ]
                },
                        
            <?php } ?>
        ]
    });
</script>