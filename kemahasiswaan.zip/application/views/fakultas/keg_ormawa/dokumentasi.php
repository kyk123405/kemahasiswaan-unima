<script>
    var url_list   = "<?= site_url('fakultas/keg_ormawa/ajax_dokumentasi/'.$id_ko); ?>";
    var url_edit   = "<?= site_url('fakultas/keg_ormawa/ajax_edit_dokumentasi/'); ?>";
    var url_add    = "<?= site_url('fakultas/keg_ormawa/ajax_add_dokumentasi/'); ?>";
    var url_update = "<?= site_url('fakultas/keg_ormawa/ajax_update_dokumentasi/'); ?>";
    var url_delete = "<?= site_url('fakultas/keg_ormawa/ajax_delete_dokumentasi/'); ?>";
</script>
<script src="<?= base_url('assets/script/keg_ormawa.js'); ?>"></script>

<?php  
    $keg_ormawa    = $this->db->where('id_ko', $id_ko)->get('keg_ormawa')->row();
?>

<div class="notifikasi"></div>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Dokumentasi Kegiatan - <?= $keg_ormawa->nama_keg ?></h1>
    <p class="mb-4"></p>

    <div class="card shadow mb-4 border-bottom-warning ">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <a href="javascript:void(0)" onclick="tambah_dokumentasi()" class="btn btn-outline-primary btn-sm">
                   <i class="fas fa-fw fa-plus"></i>
                </a>
                <a href="javascript:void(0)" onclick="reload_table()" class="btn btn-outline-danger btn-sm">
                   <i class="fas fa-fw fa-exchange-alt"></i>
                </a> 
                <a href="<?= base_url('fakultas/keg_ormawa/') ?>" class="btn btn-outline-info btn-sm">
                   <i class="fas fa-fw fa-arrow-left"></i> Kembali
                </a>               
            </h6>            
        </div>
        <div class="card-body">
            <div class="table-responsive">                
                <table class="table table-hover" id="myTable2" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="text-align: center;">File</th>
                            <th style="width: 15%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>  
</div>

<div class="modal fade" id="modal_dokumentasi" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">                
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body form">
                <form action="#" id="form_dokumentasi">
                    <input type="hidden" name="id_do" />
                    <input type="hidden" name="id_ko" id="id_ko" value="<?= $id_ko ?>" />

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="file">File</label>
                        <div class="col-sm-9">
                            <input type="file" name="file" id="file" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="simpan_dokumentasi()" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>