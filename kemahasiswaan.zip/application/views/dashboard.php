<?php  
    $sambutan_rektor = $this->db->where('level', 'Rektor')->get('sambutan')->row();
    $sambutan_wr = $this->db->where('level', 'WR')->get('sambutan')->row();
?>

<section id="hero">
  <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

    <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    <div class="carousel-inner" role="listbox">

      <!-- Slide 1 -->
      <div class="carousel-item active" style="background-image: url(assets/img/unima.jpg)">
        <div class="carousel-container">
          <div class="container">
            <h3 class="animate__animated animate__fadeInDown" style="color: white;">Selamat Datang di <span>Website</span></h3>
            <h2 class="animate__animated animate__fadeInUp"><i>Kemahasiswaan Universitas Negeri Manado</i></h2>
          </div>
        </div>
      </div>

    </div>

    <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
      <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
    </a>

    <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
      <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
    </a>

  </div>
</section>
<main id="main">
  <!-- ======= About Section ======= -->
  <section id="about" class="about">
    <div class="container">

      <div class="row content">
        <div class="col-lg-3">
          <img src="<?= base_url('uploads/tentang/'.$sambutan_rektor->foto) ?>" width="300px" alt="">

        </div>
        <div class="col-lg-9 pt-4 pt-lg-0">
          <p>
            <?= $sambutan_rektor->isi ?>
          </p>
          <hr>
          <p><b><?= $sambutan_rektor->nama ?></b><br><i><?= $sambutan_rektor->jabatan ?></i></p>
        </div>
      </div>

    </div>
  </section>
  
  <section id="about" class="about">
    <div class="container">

      <div class="row content">
        <div class="col-lg-9 pt-4 pt-lg-0">
          <p>
            <?= $sambutan_wr->isi ?>
          </p>
          <hr>
          <p><b><?= $sambutan_wr->nama ?></b><br><i><?= $sambutan_wr->jabatan ?></i></p>
        </div>
        <div class="col-lg-3
        ">
          <img src="<?= base_url('uploads/tentang/'.$sambutan_wr->foto) ?>" width="300px" alt="">
        </div>
      </div>

    </div>
  </section>

  <section id="team" class="team section-bg">
    <div class="container">
      <div class="section-title">
        <h2>Informasi</h2>
        <p>Prestasi Mahasiswa UNIMA</p>
      </div>
      <div class="row">
        <?php foreach ($prestasi_mhs as $prestasi) { ?>
          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="assets/img/logo.png" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4><?= $prestasi->nama_pm ?></h4>
                <span>Tingkat : <b><?= $prestasi->tingkat ?></b> | Peringkat : <b><?= $prestasi->juara ?></b></span>
                <p>
                    Tahun : <b><?= $prestasi->tahun ?></b><br>
                    Prestasi : <b><?= $prestasi->deskripsi_pm ?></b>
                </p>
                
              </div>
            </div>
          </div>
        <?php } ?>
        <div><hr></div>
        <div align="right">
          <a href="<?= base_url('public/prestasi_mhs') ?>" class="btn btn-sm btn-danger">Lihat Selengkapnya</a>
        </div>
      </div>
    </div>
  </section>

  <section id="blog" class="blog">
    <div class="container">
      <div class="section-title">
        <h2>Informasi</h2>
        <p>Kegiatan Kemahasiswaan</p>
      </div>
      <div class="row">
        <?php foreach ($keg_mhs as $keg) { ?>
          <div class="col-lg-4 entries">
            <article class="entry">
              <div class="entry-img">
                <img src="<?= base_url('uploads/keg_mhs/'.$keg->cover) ?>" alt="" style="height: 200px; width: 400px;" class="img-fluid">
              </div>

              <h3 class="entry-title">
                <a href="<?= base_url('keg_mhs/detail/'.$keg->id_keg_mhs) ?>" style="font-size: 16pt;"><?= $keg->nama_keg ?></a>
              </h3>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="#">Admin</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="<?= $keg->tgl_keg ?>"><?= $keg->tgl_keg ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p style="font-size: 12pt;">
                  <?= word_limiter($keg->isi_keg, 5) ?>
                </p>
                <div class="read-more">
                  <a href="<?= base_url('keg_mhs/detail/'.$keg->id_keg_mhs) ?>">Selengkapnya</a>
                </div>
              </div>

            </article>
          </div>
        <?php } ?>
        <div><hr></div>
        <div align="right">
          <a href="<?= base_url('keg_mhs') ?>" class="btn btn-sm btn-danger">Lihat Selengkapnya</a>
        </div>
      </div>

    </div>
  </section>

  <section id="portfolio" class="portfolio">
    <div class="container">
      <div class="section-title">
        <h2>Galeri</h2>
        <p>Prestasi Mahasiswa UNIMA</p>
      </div>

      <div class="row portfolio-container">
        <?php foreach ($dokumentasi as $dokumentasi) { ?>
          <?php  
            $pm = $this->db->where('id_pm', $dokumentasi->id_pm)->get('prestasi_mhs')->row();
          ?>
          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?= base_url('uploads/prestasi_mhs/'.$dokumentasi->file) ?>" class="img-fluid" alt="" style="height: 250px; width: 400px;">
              <div class="portfolio-info">
                <h4><?= $pm->nama_pm ?></h4>
                <div class="portfolio-links">
                  <a href="<?= base_url('uploads/prestasi_mhs/'.$dokumentasi->file) ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?= $pm->nama_pm ?>"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>

    </div>
  </section>
  
  <section id="blog" class="blog">
    <div class="container">
      <div class="section-title">
        <h2>Informasi</h2>
        <p>Kegiatan ORMAWA</p>
      </div>
      <div class="row">
        <?php foreach ($keg_orm as $keg) { ?>
          <div class="col-lg-4 entries">
            <article class="entry">
              <div class="entry-img">
                <img src="<?= base_url('uploads/keg_ormawa/'.$keg->cover) ?>" alt="" style="height: 200px; width: 400px;" class="img-fluid">
              </div>

              <h3 class="entry-title">
                <a href="<?= base_url('keg_ormawa/detail/'.$keg->id_ko) ?>" style="font-size: 16pt;"><?= $keg->nama_keg ?></a>
              </h3>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="#">Admin</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="<?= $keg->tgl_keg ?>"><?= $keg->tgl_keg ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p style="font-size: 12pt;">
                  <?= word_limiter($keg->isi_keg, 5) ?>
                </p>
                <div class="read-more">
                  <a href="<?= base_url('keg_ormawa/detail/'.$keg->id_ko) ?>">Selengkapnya</a>
                </div>
              </div>

            </article>
          </div>
        <?php } ?>
        <div><hr></div>
        <div align="right">
          <a href="<?= base_url('keg_ormawa') ?>" class="btn btn-sm btn-danger">Lihat Selengkapnya</a>
        </div>
      </div>

    </div>
  </section>
</main>