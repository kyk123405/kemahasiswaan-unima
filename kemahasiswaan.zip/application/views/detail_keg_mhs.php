<?php  
  $dokumentasi = $this->db->where('id_keg_mhs', $keg_mhs->id_keg_mhs)->get('dokumentasi_keg_mhs')->result();
  $kegiatan    = $this->db->where('id_keg_mhs !=', $keg_mhs->id_keg_mhs)->get('keg_mhs')->result();
?>
<br>
<br>
<main id="main">
  <section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

      <div class="d-flex justify-content-between align-items-center">
        <h2></h2>
        <ol>
          <li><a href="<?= base_url() ?>">Home</a></li>
          <li><a href="<?= base_url('keg_mhs') ?>">Kegiatan Kemahasiswaan</a></li>
          <li>Detail Kegiatan <b><?= word_limiter($keg_mhs->nama_keg, 5) ?></b></li>
        </ol>
      </div>

    </div>
  </section>

  <section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2>Informasi</h2>
        <p>Kegiatan Kemahasiswaan</p>
      </div>
      <div class="row">
        
      </div>

    </div>
  </section>

  <section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
      <div class="row">
        <div class="col-lg-8 entries">
          <article class="entry entry-single">
            <div class="entry-img">
              <img src="<?= base_url('uploads/keg_mhs/'.$keg_mhs->cover) ?>" alt="" class="img-fluid">
            </div>

            <h2 class="entry-title">
              <?= $keg_mhs->nama_keg ?>
            </h2>

            <div class="entry-meta">
              <ul>
                <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="#">Admin</a></li>
                <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="<?= $keg_mhs->tgl_keg ?>"><?= format_tanggal($keg_mhs->tgl_keg) ?></time></a></li>
              </ul>
            </div>

            <div class="entry-content">
              <p>
                <?= $keg_mhs->isi_keg ?>
              </p>
            </div>

            <div class="entry-footer">
              <i class="bi bi-folder"></i>
              <ul class="cats">
                <li><a href="#">Dokumentasi Kegiatan</a></li>
              </ul>
            </div>
            <section id="portfolio" class="portfolio">
              <div class="container">
                <div class="row portfolio-container">
                  <?php foreach ($dokumentasi as $row) { ?>
                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                      <div class="portfolio-wrap">
                        <img src="<?= base_url('uploads/keg_mhs/'.$row->file) ?>" class="img-fluid" alt="" style="height: 150px; width: 250px;">
                        <div class="portfolio-info">
                          <h6></h6>
                          <p><?= $keg_mhs->nama_keg ?></p>
                          <div class="portfolio-links">
                            <a href="<?= base_url('uploads/keg_mhs/'.$row->file) ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?= $keg_mhs->nama_keg ?>"><i class="bx bx-plus"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php } ?>
                </div>

              </div>
            </section>
          </article>
        </div>

        <div class="col-lg-4">

          <div class="sidebar">
            <h3 class="sidebar-title">Recent Posts</h3>
            <div class="sidebar-item recent-posts">
              <?php foreach ($kegiatan as $keg) { ?>
                <div class="post-item clearfix">
                  <img src="<?= base_url('uploads/keg_mhs/'.$keg->cover) ?>" alt="">
                  <h4><a href="<?= base_url('keg_mhs/detail/'.$keg->id_keg_mhs) ?>"><?= $keg->nama_keg ?></a></h4>
                  <time datetime="2020-01-01"><?= format_tanggal($keg->tgl_keg) ?></time>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>