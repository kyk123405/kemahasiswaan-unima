<?php  
  $dokumentasi = $this->db->where('id_pm', $prestasi_mhs->id_pm)->get('dokumentasi_pm')->result();
  $prestasi    = $this->db->where('id_pm !=', $prestasi_mhs->id_pm)->get('prestasi_mhs', 5)->result();
?>
<br>
<br>
<main id="main">
  <section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

      <div class="d-flex justify-content-between align-items-center">
        <h2></h2>
        <ol>
          <li><a href="<?= base_url() ?>">Home</a></li>
          <li>Detail Prestasi <b><?= word_limiter($prestasi_mhs->nama_pm, 5) ?></b></li>
        </ol>
      </div>

    </div>
  </section>

  <section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2>Informasi</h2>
        <p>Prestasi Mahasiswa</p>
      </div>
      <div class="row">
        
      </div>

    </div>
  </section>

  <section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
      <div class="row">
        <div class="col-lg-8 entries">
          <article class="entry entry-single">

            <h2 class="entry-title">
              <?= $prestasi_mhs->nama_pm ?>
            </h2>

            <div class="entry-meta">
              <ul>
                <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="#">Admin</a></li>
                <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="<?= $prestasi_mhs->tahun ?>">Tahun : <?= $prestasi_mhs->tahun ?></time></a></li>
              </ul>
            </div>

            <div class="entry-content">
              <p>
                <?= $prestasi_mhs->deskripsi_pm ?>
              </p>
            </div>

            <div class="entry-footer">
              <i class="bi bi-folder"></i>
              <ul class="cats">
                <li><a href="#">Dokumentasi</a></li>
              </ul>
            </div>
            <section id="portfolio" class="portfolio">
              <div class="container">
                <div class="row portfolio-container">
                  <?php foreach ($dokumentasi as $row) { ?>
                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                      <div class="portfolio-wrap">
                        <img src="<?= base_url('uploads/prestasi_mhs/'.$row->file) ?>" class="img-fluid" alt="" style="height: 150px; width: 250px;">
                        <div class="portfolio-info">
                          <h6></h6>
                          <p><?= $prestasi_mhs->nama_pm ?></p>
                          <div class="portfolio-links">
                            <a href="<?= base_url('uploads/prestasi_mhs/'.$row->file) ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?= $prestasi_mhs->nama_pm ?>"><i class="bx bx-plus"></i></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php } ?>
                </div>

              </div>
            </section>
          </article>
        </div>

        <div class="col-lg-4">

          <div class="sidebar">
            <h3 class="sidebar-title">Recent Posts</h3>
            <div class="sidebar-item recent-posts">
              <?php foreach ($prestasi as $keg) { ?>
                <div class="post-item clearfix">
                  <img src="<?= base_url('assets/img/logo.png') ?>" alt="">
                  <h4><a href="<?= base_url('dashboard/prestasi_mhs/'.$keg->id_pm) ?>"><?= $keg->nama_pm ?></a></h4>
                  <time datetime="2020-01-01"><?= $keg->tahun ?></time>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>