<script>
    var url_list   = "<?= site_url('admin/renaksi_univ/ajax_list'); ?>";
    var url_detail = "<?= site_url('admin/renaksi_univ/detail_renaksi_univ/'); ?>";
</script>
<script src="<?= base_url('assets/script/renaksi_univ.js'); ?>"></script>

<div class="notifikasi"></div>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Daftar Rencana Aksi Universitas Negeri Manado</h1>
    <p class="mb-4"></p>

    <div class="card shadow mb-4 border-bottom-warning ">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <a href="<?= base_url('admin/renaksi_univ/export_data') ?>" class="btn btn-outline-success btn-sm">
                   <i class="fas fa-fw fa-file-alt"></i> Export Renaksi
                </a>
                <a href="javascript:void(0)" onclick="reload_table()" class="btn btn-outline-danger btn-sm">
                   <i class="fas fa-fw fa-exchange-alt"></i>
                </a>                
            </h6>            
        </div>
        <div class="card-body">
            <div class="table-responsive">                
                <table class="table table-hover" id="myTable2" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="width: 20%; text-align: center; word-wrap: break-word;">Sasaran Kegiatan</th>
                            <th style="width: 30%; text-align: center; word-wrap: break-word;">Indikator Kinerja Kegiatan</th>
                            <th style="text-align: center; word-wrap: break-word;">Satuan</th>
                            <th style="text-align: center; word-wrap: break-word;">Target PK</th>
                            <th style="text-align: center; word-wrap: break-word;">Target TW 1</th>
                            <th style="text-align: center; word-wrap: break-word;">Target TW 2</th>
                            <th style="text-align: center; word-wrap: break-word;">Target TW 3</th>
                            <th style="text-align: center; word-wrap: break-word;">Target TW 4</th>
                            <th style="width: 10%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>    
</div>

<div class="modal fade" id="modal_detail" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body form">
                <div class="form-group text-left">
                    <table class="table">
                        <tr>
                            <th width="25%">Sasaran Kegiatan</th>
                            <td>
                                <b><div id="nama_sasaran"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Kode IKK</th>
                            <td>
                                <b><div id="kode_ikk_univ"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Nama IKK</th>
                            <td>
                                <b><div id="nama_ikk_univ"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Satuan</th>
                            <td>
                                <b><div id="satuan"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target PK</th>
                            <td>
                                <b><div id="target_pk"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 1</th>
                            <td>
                                <b><div id="target_tw1"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 2</th>
                            <td>
                                <b><div id="target_tw2"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 3</th>
                            <td>
                                <b><div id="target_tw3"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 4</th>
                            <td>
                                <b><div id="target_tw4"></div></b>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Kembali</button>
            </div>
        </div>
    </div>
</div>