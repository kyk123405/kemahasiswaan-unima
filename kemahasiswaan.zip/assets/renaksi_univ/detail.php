<script>
    var url_list   = "<?= site_url('admin/ikk_univ/ajax_ikk/'.$id_sasaran); ?>";
    var url_edit   = "<?= site_url('admin/ikk_univ/ajax_edit_ikk_univ/'); ?>";
    var url_add    = "<?= site_url('admin/ikk_univ/ajax_add_ikk_univ/'); ?>";
    var url_update = "<?= site_url('admin/ikk_univ/ajax_update_ikk_univ/'); ?>";
    var url_delete = "<?= site_url('admin/ikk_univ/ajax_delete_ikk_univ/'); ?>";
    var url_detail = "<?= site_url('admin/ikk_univ/detail_ikk_univ/'); ?>";
</script>
<script src="<?= base_url('assets/script/ikk_univ.js'); ?>"></script>

<?php  
    $sasaran    = $this->db->where('id_sasaran', $id_sasaran)->get('sasaran')->row();
?>

<div class="notifikasi"></div>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Detail Data Sasaran Kegiatan - <?= $sasaran->kode_sasaran ?></h1>
    <p class="mb-4"></p>

    <div class="card shadow mb-4 border-bottom-warning ">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <a href="javascript:void(0)" onclick="tambah_ikk()" class="btn btn-outline-primary btn-sm">
                   <i class="fas fa-fw fa-plus"></i>
                </a>
                <a href="<?= base_url('admin/ikk_univ/export_data') ?>" class="btn btn-outline-success btn-sm">
                   <i class="fas fa-fw fa-file-alt"></i> Export IKK Lengkap
                </a>
                <a href="javascript:void(0)" onclick="reload_table()" class="btn btn-outline-danger btn-sm">
                   <i class="fas fa-fw fa-exchange-alt"></i>
                </a> 
                <a href="<?= base_url('admin/ikk_univ/') ?>" class="btn btn-outline-info btn-sm">
                   <i class="fas fa-fw fa-arrow-left"></i> Kembali
                </a>               
            </h6>            
        </div>
        <div class="card-body">
            <div class="table-responsive">                
                <table class="table table-hover" id="myTable2" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="text-align: center;">Kode IKK</th>
                            <th style="text-align: center;">Nama IKK</th>
                            <th style="text-align: center;">Satuan</th>
                            <th style="text-align: center;">target PK</th>
                            <th style="width: 20%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>  
</div>

<div class="modal fade" id="modal_ikk_univ" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">                
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body form">
                <form action="#" id="form_ikk_univ">
                    <input type="hidden" name="id_ikk_univ" />
                    <input type="hidden" name="id_sasaran" id="id_sasaran" value="<?= $id_sasaran ?>" />

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="kode_ikk_univ">Kode IKK</label>
                        <div class="col-sm-9">
                            <input type="text" name="kode_ikk_univ" id="kode_ikk_univ" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="nama_ikk_univ">Nama IKK</label>
                        <div class="col-sm-9">
                            <input type="text" name="nama_ikk_univ" id="nama_ikk_univ" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="satuan">Satuan</label>
                        <div class="col-sm-9">
                            <input type="text" name="satuan" id="satuan" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="target_pk">Target PK</label>
                        <div class="col-sm-9">
                            <input type="text" name="target_pk" id="target_pk" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="target_tw1">Target TW 1</label>
                        <div class="col-sm-9">
                            <input type="text" name="target_tw1" id="target_tw1" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="target_tw2">Target TW 2</label>
                        <div class="col-sm-9">
                            <input type="text" name="target_tw2" id="target_tw2" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="target_tw3">Target TW 3</label>
                        <div class="col-sm-9">
                            <input type="text" name="target_tw3" id="target_tw3" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label col-form-label-sm" for="target_tw4">Target TW 4</label>
                        <div class="col-sm-9">
                            <input type="text" name="target_tw4" id="target_tw4" class="form-control form-control-sm" />
                            <span class="help-block text-danger" style="font-size: 10pt"></span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="simpan_ikk_univ()" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal_detail" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"></h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body form">
                <div class="form-group text-left">
                    <table class="table">
                        <tr>
                            <th width="25%">Sasaran Kegiatan</th>
                            <td>
                                <b><div id="nama_sasaran"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Kode IKK</th>
                            <td>
                                <b><div id="kode_ikk_univ"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Nama IKK</th>
                            <td>
                                <b><div id="nama_ikk_univ"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Satuan</th>
                            <td>
                                <b><div id="satuan"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target PK</th>
                            <td>
                                <b><div id="target_pk"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 1</th>
                            <td>
                                <b><div id="target_tw1"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 2</th>
                            <td>
                                <b><div id="target_tw2"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 3</th>
                            <td>
                                <b><div id="target_tw3"></div></b>
                            </td>
                        </tr>

                        <tr>
                            <th width="25%">Target TW 4</th>
                            <td>
                                <b><div id="target_tw4"></div></b>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Kembali</button>
            </div>
        </div>
    </div>
</div>