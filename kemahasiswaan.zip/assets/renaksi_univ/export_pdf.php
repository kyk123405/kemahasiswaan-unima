<!DOCTYPE>
<html>
    <head>        
        <title>Rencana Aksi UNIMA</title>
        <style>
            h1 {
                text-align: center; 
                font-size: 14px;
                margin-top: 50px;
            }            
            table {
                font-size: 12px;
                border-collapse: collapse;
                align: center;
            }
            .zebra{
                background-color: #ffffff;
            }
            th, td {
                padding: 4px 2px;
            }
            th, tfoot tr td {
                background-color: #cccccc;
            }
        </style>
    </head>
    <body>
        <br>
        <br>
        <div align="center">
            <img src="<?= base_url('assets/img/kementerian.png') ?>" style="width: 10%;" align="center">
        </div>
        <br>
        <div align="center">
            <b style="text-align: center; font-size: 12pt;">
                Rencana Aksi  <br>
                Universitas Negeri Manado <br>
                Tahun <?= date('Y') ?>
            </b>
        </div>
        <br>
        <br>
        <br>
        <div style="margin-top: 20px; margin-left: 27px;">
            <b style="font-size: 12pt;">
                Rencana Aksi Perjanjian Kinerja
            </b>
        </div>
        <table style="width: 100%; padding: 30px; font-size: 12pt; vertical-align: top;" border="1">
            <tr>
                <td style="width: 5%; text-align: center;"><b>#</b></td>
                <td style="width: 20%; text-align: center;"><b>Sasaran Kegiatan</b></td>
                <td style="width: 20%; text-align: center;"><b>Indikator Kinerja Kegiatan</b></td>
                <td style="width: 15%; text-align: center;"><b>Target Perjanjian Kinerja 2022</b></td>
                <td style="width: 10%; text-align: center;"><b>Target TW 1</b></td>
                <td style="width: 10%; text-align: center;"><b>Target TW 2</b></td>
                <td style="width: 10%; text-align: center;"><b>Target TW 3</b></td>
                <td style="width: 10%; text-align: center;"><b>Target TW 4</b></td>
            </tr>
            <?php $no=1; foreach ($ikk_univ as $rows) { ?>
                <?php $sasaran = $this->db->where('id_sasaran', $rows->id_sasaran)->get('sasaran')->row(); ?>
                <tr>
                    <td style="width: 5%; text-align: center;"><?php echo $no++ ?></td>
                    <td style="width: 20%; word-wrap: break-word;">[<?php echo $sasaran->kode_sasaran ?>] <?php echo $sasaran->nama_sasaran ?></td>
                    <td style="width: 25%; word-wrap: break-word;">[<?php echo $rows->kode_ikk_univ ?>] <?php echo $rows->nama_ikk_univ ?></td>
                    <td style="width: 10%; word-wrap: break-word; text-align: center;"><?php echo $rows->target_pk ?> <?php echo $rows->satuan ?></td>
                    <td style="width: 10%; word-wrap: break-word; text-align: center;"><?php echo $rows->target_tw1 ?></td>
                    <td style="width: 10%; word-wrap: break-word; text-align: center;"><?php echo $rows->target_tw2 ?></td>
                    <td style="width: 10%; word-wrap: break-word; text-align: center;"><?php echo $rows->target_tw3 ?></td>
                    <td style="width: 10%; word-wrap: break-word; text-align: center;"><?php echo $rows->target_tw4 ?></td>
                </tr>
            <?php } ?>
        </table>
        <b>
            <table style="width: 100%; padding: 30px; font-size: 12pt; text-align: center; vertical-align: top;" border="0">
                <tr>
                    <td style="width: 50%; vertical-align: top;">
                        
                    </td>
                    <td style="width: 50%;">
                        <?php $today = date('Y-m-d') ?>
                        Manado, <?= format_tanggal($today) ?>
                        <br>
                        Rektor Universitas Negeri Manado
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        Prof. Dr. Deitje Adolfien Katuuk, M.Pd
                    </td>
                </tr>
            </table>
        </b>
    </body>
</html>
