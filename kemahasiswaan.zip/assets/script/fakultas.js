var save_method;
var table;

$(document).ready(function() {
    table = $('#myTable2').DataTable({
        "autoWidth": true,
        "pageLength": 15,
        "lengthChange": false,
        "ordering": false,
        "processing": true,
        "searching": true,
        "scroller": {
            "loadingIndicator": true
        },
        "order": [],
        "ajax": {
            "url": url_list,
            "type": "GET"
        },
        "serverSide": true,
        "deferRender": true,
        "columnDefs": [
            { 
                "targets": [ 0 ],
                "orderable": false,
            },
            { 
                "targets": [ -1 ],
                "orderable": false,
            },
        ],
        "language": {
            "decimal":        "",
            "emptyTable":     "Tidak ada data...",
            "info":           "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            "infoEmpty":      "Menampilkan 0 sampai 0 dari 0 data",
            "infoFiltered":   "(filter dari _MAX_ total data)",
            "infoPostFix":    "",
            "thousands":      ".",
            "lengthMenu":     "Menampilkan _MENU_ data",
            "loadingRecords": "Menunggu...",
            "processing":     "Memproses data...",
            "search":         "Pencarian :",
            "zeroRecords":    "Tidak ada data yang ditemukan",
            "paginate": {
                "first":      "Pertama",
                "last":       "Terakhir",
                "next":       "Berikutnya",
                "previous":   "Sebelumnnya"
            },
            "aria": {
                "sortAscending":  ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            }
        }
    });

    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });

    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
});

function reload_table() {
    window.location.reload();
}

function tambah() {
    save_method = 'add';
    $('#form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_form').modal('show');
    $('.modal-title').text('Tambah Data');
}

function simpan() {
    $('#btnSave').text('menyimpan...');
    $('#btnSave').attr('disabled',true);    
    var url;

    if(save_method == 'add') {
        url = url_add;
    } else {
        url = url_update;
    }

    var formData = new FormData($('#form')[0]);
    $.ajax({        
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if(data.status) {                
                $('#modal_form').modal('hide');
                success("Data berhasil di simpan.");                
                reload_table();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error');
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                }
            }
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Data gagal disimpan');
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        }
    });
}

function edit(id_fakultas) {
    save_method = 'update';
    $('#form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();

    $.ajax({
        url : url_edit + id_fakultas,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('[name="id_fakultas"]').val(data.id_fakultas);
            $('[name="nama_fakultas"]').val(data.nama_fakultas);
            $('[name="singkatan"]').val(data.singkatan);

            $('#modal_form').modal('show');
            $('.modal-title').text('Ubah Data');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Gagal mengambil data');
        }
    });    
}

function hapus(id_fakultas) {
    if(confirm('Anda yakin ingin menghapus data ini?')) {
        $.ajax({
            url : url_delete + id_fakultas,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                success('Data berhasil dihapus');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                error('Data gagal dihapus');
            }
        });
    }
}

function success(text) {    
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-success role="alert"">' + text + '</div>');
}

function error(text) {
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-danger role="alert"">' + text + '</div>');
}

function warning(text) {
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-warning role="alert"">' + text + '</div>');
}