var save_method;
var table;

$(document).ready(function() {
    table = $('#myTable2').DataTable({
        "autoWidth": true,
        "pageLength": 15,
        "lengthChange": false,
        "ordering": false,
        "processing": true,
        "searching": true,
        "scroller": {
            "loadingIndicator": true
        },
        "order": [],
        "ajax": {
            "url": url_list,
            "type": "GET"
        },
        "serverSide": true,
        "deferRender": true,
        "columnDefs": [
            { 
                "targets": [ 0 ],
                "orderable": false,
            },
            { 
                "targets": [ -1 ],
                "orderable": false,
            },
        ],
        "language": {
            "decimal":        "",
            "emptyTable":     "Tidak ada data...",
            "info":           "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            "infoEmpty":      "Menampilkan 0 sampai 0 dari 0 data",
            "infoFiltered":   "(filter dari _MAX_ total data)",
            "infoPostFix":    "",
            "thousands":      ".",
            "lengthMenu":     "Menampilkan _MENU_ data",
            "loadingRecords": "Menunggu...",
            "processing":     "Memproses data...",
            "search":         "Pencarian :",
            "zeroRecords":    "Tidak ada data yang ditemukan",
            "paginate": {
                "first":      "Pertama",
                "last":       "Terakhir",
                "next":       "Berikutnya",
                "previous":   "Sebelumnnya"
            },
            "aria": {
                "sortAscending":  ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            }
        }
    });

    $("input").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });

    $("textarea").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
    
    $("select").change(function(){
        $(this).parent().parent().removeClass('has-error');
        $(this).next().empty();
    });
});

function reload_table() {
    window.location.reload();
}

function tambah() {
    save_method = 'add';
    $('#form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_form').modal('show');
    $('.modal-title').text('Tambah Data');
}

function tambah_ikk() {
    save_method = 'add';
    $('#form_ikk_univ')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_ikk_univ').modal('show');
    $('.modal-title').text('Tambah Data');
}

function simpan() {
    $('#btnSave').text('menyimpan...');
    $('#btnSave').attr('disabled',true);    
    var url;

    if(save_method == 'add') {
        url = url_add;
    } else {
        url = url_update;
    }

    var formData = new FormData($('#form')[0]);
    $.ajax({        
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if(data.status) {                
                $('#modal_form').modal('hide');
                success("Data berhasil di simpan.");                
                reload_table();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error');
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                }
            }
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Data gagal disimpan');
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        }
    });
}

function simpan_ikk_univ() {
    $('#btnSave').text('menyimpan...');
    $('#btnSave').attr('disabled',true);    
    var url;

    if(save_method == 'add') {
        url = url_add;
    } else {
        url = url_update;
    }

    var formData = new FormData($('#form_ikk_univ')[0]);
    $.ajax({        
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data) {
            if(data.status) {                
                $('#modal_ikk_univ').modal('hide');
                success("Data berhasil di simpan.");                
                reload_table();
            } else {
                for (var i = 0; i < data.inputerror.length; i++) {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error');
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]);
                }
            }
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Data gagal disimpan');
            $('#btnSave').text('Simpan');
            $('#btnSave').attr('disabled',false);            
        }
    });
}

function edit(id_sasaran) {
    save_method = 'update';
    $('#form')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();

    $.ajax({
        url : url_edit + id_sasaran,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('[name="id_sasaran"]').val(data.id_sasaran);
            $('[name="nama_sasaran"]').val(data.nama_sasaran);
            $('[name="kode_sasaran"]').val(data.kode_sasaran);

            $('#modal_form').modal('show');
            $('.modal-title').text('Ubah Data');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Gagal mengambil data');
        }
    });    
}

function edit_ikk_univ(id_ikk_univ) {
    save_method = 'update';
    $('#form_ikk_univ')[0].reset();
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();

    $.ajax({
        url : url_edit + id_ikk_univ,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('[name="id_ikk_univ"]').val(data.id_ikk_univ);
            $('[name="kode_ikk_univ"]').val(data.kode_ikk_univ);
            $('[name="nama_ikk_univ"]').val(data.nama_ikk_univ);
            $('[name="satuan"]').val(data.satuan);
            $('[name="target_pk"]').val(data.target_pk);
            $('[name="target_tw1"]').val(data.target_tw1);
            $('[name="target_tw2"]').val(data.target_tw2);
            $('[name="target_tw3"]').val(data.target_tw3);
            $('[name="target_tw4"]').val(data.target_tw4);

            $('#modal_ikk_univ').modal('show');
            $('.modal-title').text('Ubah Data');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            error('Gagal mengambil data');
        }
    });    
}

function hapus(id_sasaran) {
    if(confirm('Anda yakin ingin menghapus data ini?')) {
        $.ajax({
            url : url_delete + id_sasaran,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                success('Data berhasil dihapus');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                error('Data gagal dihapus');
            }
        });
    }
}

function hapus_ikk_univ(id_ikk_univ) {
    if(confirm('Anda yakin ingin menghapus data ini?')) {
        $.ajax({
            url : url_delete + id_ikk_univ,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                success('Data berhasil dihapus');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                error('Data gagal dihapus');
            }
        });
    }
}

function detail_ikk_univ(id_ikk_univ) {
    $.ajax({
        url : url_detail + id_ikk_univ,
        type: "GET",
        dataType: "JSON",
        success: function(data) {
            $('div#id_ikk_univ').html(data.id_ikk_univ);
            $('div#nama_ikk_univ').html(data.nama_ikk_univ);
            $('div#kode_ikk_univ').html(data.kode_ikk_univ);
            $('div#nama_sasaran').html(data.nama_sasaran);
            $('div#satuan').html(data.satuan);
            $('div#target_pk').html(data.target_pk);
            $('div#target_tw1').html(data.target_tw1);
            $('div#target_tw2').html(data.target_tw2);
            $('div#target_tw3').html(data.target_tw3);
            $('div#target_tw4').html(data.target_tw4);
            


            $('#modal_detail').modal('show');
            $('.modal-title').text('Detail Data');
        },
        error: function (jqXHR, textStatus, errorThrown) {
            notif('error', 'Error', 'unit Error!');
        }
    });    
}

function success(text) {    
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-success role="alert"">' + text + '</div>');
}

function error(text) {
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-danger role="alert"">' + text + '</div>');
}

function warning(text) {
    $('.notifikasi').fadeIn().delay(3000).fadeOut('slow').html('<div class="alert alert-warning role="alert"">' + text + '</div>');
}